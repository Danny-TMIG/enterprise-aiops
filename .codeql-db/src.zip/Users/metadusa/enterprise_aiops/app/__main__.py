from fastapi import FastAPI
from app.middleware.verification import VerificationMiddleware, engine

app = FastAPI(title="Enterprise AIOps Orchestrator Matrix", version="3.0.0")
app.add_middleware(VerificationMiddleware)

@app.get("/health")
def health(): return {"status": "healthy", "locked": engine.locked, "owner": engine.owner, "hardware": "Apple M4 Max / MLX Unified Memory"}

@app.post("/state/commit")
def commit(payload: dict): return {"status": "committed", "registry_size": len(engine.corpus_registry)}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.__main__:app", host="127.0.0.1", port=8000, reload=True)
