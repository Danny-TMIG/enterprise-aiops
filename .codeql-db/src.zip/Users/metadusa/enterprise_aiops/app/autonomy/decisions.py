"""Deterministic autonomous decision engine.

No LLM. Rules are (name, condition, action) where condition is a
pure function of the current observation, and action returns a
Decision describing what to do.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


@dataclass(frozen=True)
class Decision:
    rule: str
    action: str
    params: Dict[str, Any] = field(default_factory=dict)
    severity: str = "info"          # info | warn | critical
    ts: str = field(default_factory=_now)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "rule": self.rule,
            "action": self.action,
            "params": self.params,
            "severity": self.severity,
            "ts": self.ts,
        }


@dataclass(frozen=True)
class Rule:
    name: str
    condition: Callable[[Dict[str, Any]], bool]
    action: Callable[[Dict[str, Any]], Decision]
    priority: int = 100
    cooldown_s: int = 0


class DecisionEngine:
    def __init__(self) -> None:
        self._rules: List[Rule] = []
        self._last_fired: Dict[str, float] = {}

    def add(self, rule: Rule) -> "DecisionEngine":
        self._rules.append(rule)
        self._rules.sort(key=lambda r: r.priority)
        return self

    def rules(self) -> List[str]:
        return [r.name for r in self._rules]

    def evaluate(self, obs: Dict[str, Any]) -> List[Decision]:
        import time
        now = time.time()
        out: List[Decision] = []
        for r in self._rules:
            if r.cooldown_s and (now - self._last_fired.get(r.name, 0)) < r.cooldown_s:
                continue
            try:
                if r.condition(obs):
                    d = r.action(obs)
                    self._last_fired[r.name] = now
                    out.append(d)
            except Exception as exc:  # noqa: BLE001
                out.append(Decision(
                    rule=r.name,
                    action="noop",
                    params={"error": type(exc).__name__},
                    severity="warn",
                ))
        return out
