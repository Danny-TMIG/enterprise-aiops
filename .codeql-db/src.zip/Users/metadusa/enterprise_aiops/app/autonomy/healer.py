"""Healer — executes bounded, idempotent remedies."""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


@dataclass(frozen=True)
class Remedy:
    name: str
    fn: Callable[[Dict[str, Any]], Dict[str, Any]]
    max_calls_per_minute: int = 6

    def __hash__(self) -> int:
        return hash(self.name)


class Healer:
    def __init__(self) -> None:
        self._remedies: Dict[str, Remedy] = {}
        self._calls: Dict[str, List[float]] = {}
        self._history: List[Dict[str, Any]] = []

    def register(self, remedy: Remedy) -> "Healer":
        self._remedies[remedy.name] = remedy
        return self

    def available(self) -> List[str]:
        return list(self._remedies)

    def apply(self, name: str, params: Dict[str, Any]) -> Dict[str, Any]:
        import time
        r = self._remedies.get(name)
        if r is None:
            return {"ok": False, "error": "unknown remedy"}
        now = time.time()
        window = [t for t in self._calls.get(name, []) if now - t < 60]
        if len(window) >= r.max_calls_per_minute:
            return {"ok": False, "error": "rate limited"}
        window.append(now)
        self._calls[name] = window
        try:
            result = r.fn(params)
            record = {"remedy": name, "ok": True, "result": result, "ts": _now()}
        except Exception as exc:  # noqa: BLE001
            record = {"remedy": name, "ok": False, "error": type(exc).__name__, "ts": _now()}
        self._history.append(record)
        return record

    def history(self, limit: int = 50) -> List[Dict[str, Any]]:
        return self._history[-limit:]
