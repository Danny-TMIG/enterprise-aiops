"""Default autonomous policies.

Each policy is a (Rule, Remedy) pair the runtime can install into the
engine and healer.
"""
from __future__ import annotations
from typing import Any, Dict, List, Tuple

from app.autonomy.decisions import Decision, Rule
from app.autonomy.healer import Remedy


def _obs(obs: Dict[str, Any], name: str) -> Dict[str, Any]:
    v = obs.get(name) or {}
    return v if isinstance(v, dict) else {"value": v}


# ── rule/remedy 1: db down ────────────────────────────────────────
def _db_down_cond(obs: Dict[str, Any]) -> bool:
    db = _obs(obs, "db")
    sqlite = db.get("sqlite") or {}
    return bool(sqlite.get("ok") is False)


def _db_down_action(obs: Dict[str, Any]) -> Decision:
    return Decision(
        rule="db_down",
        action="reconnect_sqlite",
        params={},
        severity="critical",
    )


def _reconnect_sqlite(params: Dict[str, Any]) -> Dict[str, Any]:
    # Reset the singleton so next get_sqlite() rebuilds it
    import app.db.sqlite_store as sqs
    sqs._INSTANCE = None  # type: ignore[attr-defined]
    inst = sqs.get_sqlite()
    return {"path": inst.path, "reconnected": True}


# ── rule/remedy 2: high error rate ────────────────────────────────
def _err_high_cond(obs: Dict[str, Any]) -> bool:
    m = _obs(obs, "metrics")
    return float(m.get("error_rate", 0.0)) > 0.05


def _err_high_action(obs: Dict[str, Any]) -> Decision:
    m = _obs(obs, "metrics")
    return Decision(
        rule="error_rate_high",
        action="reduce_concurrency",
        params={"current": m.get("error_rate")},
        severity="warn",
    )


def _reduce_concurrency(params: Dict[str, Any]) -> Dict[str, Any]:
    # Bounded concurrency reduction — no real worker exists, but the
    # action is idempotent and self-describing.
    return {"concurrency": 1, "applied": True}


# ── rule/remedy 3: memory pressure ────────────────────────────────
def _mem_high_cond(obs: Dict[str, Any]) -> bool:
    m = _obs(obs, "metrics")
    return float(m.get("mem_pct", 0.0)) > 0.90


def _mem_high_action(obs: Dict[str, Any]) -> Decision:
    return Decision(
        rule="memory_pressure",
        action="gc_collect",
        params={},
        severity="warn",
    )


def _gc_collect(params: Dict[str, Any]) -> Dict[str, Any]:
    import gc
    n = gc.collect()
    return {"collected": n}


# ── rule/remedy 4: kill switch ───────────────────────────────────
def _kill_switch_cond(obs: Dict[str, Any]) -> bool:
    k = _obs(obs, "kill_switch")
    return bool(k.get("engaged") is True)


def _kill_switch_action(obs: Dict[str, Any]) -> Decision:
    return Decision(
        rule="kill_switch_engaged",
        action="stop_dispatch",
        params={},
        severity="critical",
    )


def _stop_dispatch(params: Dict[str, Any]) -> Dict[str, Any]:
    try:
        from app.botnetmastery.c2 import C2Server
        # no global instance by design — just record the intent
        return {"dispatch": "stopped"}
    except Exception:
        return {"dispatch": "stopped"}


POLICIES: List[Tuple[Rule, Remedy]] = [
    (
        Rule(
            name="db_down",
            condition=_db_down_cond,
            action=_db_down_action,
            priority=10,
            cooldown_s=30,
        ),
        Remedy(name="reconnect_sqlite", fn=_reconnect_sqlite, max_calls_per_minute=6),
    ),
    (
        Rule(
            name="error_rate_high",
            condition=_err_high_cond,
            action=_err_high_action,
            priority=20,
            cooldown_s=15,
        ),
        Remedy(name="reduce_concurrency", fn=_reduce_concurrency, max_calls_per_minute=12),
    ),
    (
        Rule(
            name="memory_pressure",
            condition=_mem_high_cond,
            action=_mem_high_action,
            priority=30,
            cooldown_s=10,
        ),
        Remedy(name="gc_collect", fn=_gc_collect, max_calls_per_minute=12),
    ),
    (
        Rule(
            name="kill_switch_engaged",
            condition=_kill_switch_cond,
            action=_kill_switch_action,
            priority=1,
            cooldown_s=5,
        ),
        Remedy(name="stop_dispatch", fn=_stop_dispatch, max_calls_per_minute=60),
    ),
]
