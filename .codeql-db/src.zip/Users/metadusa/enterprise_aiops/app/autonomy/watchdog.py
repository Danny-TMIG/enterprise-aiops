"""Watchdog — periodically samples probes and feeds the decision engine."""
from __future__ import annotations
import threading, time
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional

from app.autonomy.decisions import Decision, DecisionEngine


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


@dataclass
class Probe:
    name: str
    fn: Callable[[], Dict[str, Any]]
    interval_s: float = 5.0


class Watchdog:
    def __init__(self, engine: DecisionEngine, probes: Optional[List[Probe]] = None):
        self.engine = engine
        self.probes: List[Probe] = probes or []
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self._last: Dict[str, Dict[str, Any]] = {}
        self._decisions: List[Decision] = []

    def add(self, probe: Probe) -> "Watchdog":
        self.probes.append(probe)
        return self

    def snapshot(self) -> Dict[str, Any]:
        obs: Dict[str, Any] = {"ts": _now()}
        for p in self.probes:
            try:
                obs[p.name] = p.fn()
            except Exception as exc:  # noqa: BLE001
                obs[p.name] = {"ok": False, "error": type(exc).__name__}
        return obs

    def step(self) -> List[Decision]:
        obs = self.snapshot()
        self._last = obs
        ds = self.engine.evaluate(obs)
        self._decisions.extend(ds)
        return ds

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=2.0)

    def _loop(self) -> None:
        # Simple loop: one step per second; probes carry their own interval
        while not self._stop.is_set():
            try:
                self.step()
            except Exception:
                pass
            time.sleep(1.0)

    def last_observation(self) -> Dict[str, Any]:
        return self._last

    def recent_decisions(self, limit: int = 50) -> List[Dict[str, Any]]:
        return [d.to_dict() for d in self._decisions[-limit:]]
