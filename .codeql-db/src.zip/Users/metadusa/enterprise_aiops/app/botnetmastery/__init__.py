"""
botnetmastery — defensive simulation of a botnet C2.

SAFETY:
  * No sockets are opened.
  * No processes are spawned.
  * No files are written outside the local SQLite database.
  * A global kill switch halts all task dispatch.
"""
from app.botnetmastery.models import Bot, Task, Command, Result
from app.botnetmastery.c2 import C2Server
from app.botnetmastery.simulation import Simulation

__all__ = ["Bot", "Task", "Command", "Result", "C2Server", "Simulation"]
