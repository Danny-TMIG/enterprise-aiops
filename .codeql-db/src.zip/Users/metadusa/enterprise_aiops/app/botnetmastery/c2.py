from __future__ import annotations
import hashlib, json, sqlite3
from pathlib import Path
from typing import List, Optional

from app.botnetmastery.models import Bot, Task


SCHEMA = """
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS bots (
    id TEXT PRIMARY KEY, hostname TEXT NOT NULL, os TEXT NOT NULL,
    arch TEXT NOT NULL, first_seen TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
    last_seen TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
    status TEXT NOT NULL DEFAULT 'idle', tags TEXT NOT NULL DEFAULT '[]'
);
CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    bot_id TEXT NOT NULL REFERENCES bots(id) ON DELETE CASCADE,
    kind TEXT NOT NULL, payload TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
    dispatched_at TEXT, completed_at TEXT,
    status TEXT NOT NULL DEFAULT 'queued'
);
CREATE TABLE IF NOT EXISTS commands (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    issued_by TEXT NOT NULL,
    issued_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
    signature TEXT NOT NULL, revoked INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    bot_id TEXT NOT NULL REFERENCES bots(id) ON DELETE CASCADE,
    output TEXT NOT NULL,
    received_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
    success INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS kill_switch (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    engaged INTEGER NOT NULL DEFAULT 0,
    engaged_at TEXT, reason TEXT
);
INSERT OR IGNORE INTO kill_switch(id, engaged) VALUES (1, 0);
CREATE INDEX IF NOT EXISTS idx_tasks_bot   ON tasks(bot_id, status);
CREATE INDEX IF NOT EXISTS idx_results_bot ON results(bot_id, received_at DESC);
"""


class C2Server:
    """In-process C2 simulation. No network. No execution."""

    def __init__(self, db_path: str):
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)
        self.conn.commit()

    # ── kill switch ────────────────────────────────────────────
    def kill_switch_engaged(self) -> bool:
        cur = self.conn.execute("SELECT engaged FROM kill_switch WHERE id=1")
        return bool(cur.fetchone()["engaged"])

    def engage_kill_switch(self, reason: str = "manual") -> None:
        self.conn.execute(
            "UPDATE kill_switch SET engaged=1, engaged_at=strftime('%Y-%m-%dT%H:%M:%SZ','now'), reason=? WHERE id=1",
            (reason,),
        )
        self.conn.commit()

    def disengage_kill_switch(self) -> None:
        self.conn.execute(
            "UPDATE kill_switch SET engaged=0, engaged_at=NULL, reason=NULL WHERE id=1"
        )
        self.conn.commit()

    # ── bots ───────────────────────────────────────────────────
    def register_bot(self, bot: Bot) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO bots(id, hostname, os, arch, first_seen, last_seen, status, tags) "
            "VALUES (?,?,?,?,?,?,?,?)",
            (bot.id, bot.hostname, bot.os, bot.arch,
             bot.first_seen, bot.last_seen, bot.status, json.dumps(bot.tags)),
        )
        self.conn.commit()

    def get_bot(self, bot_id: str) -> Optional[sqlite3.Row]:
        cur = self.conn.execute("SELECT * FROM bots WHERE id=?", (bot_id,))
        return cur.fetchone()

    def list_bots(self, status: Optional[str] = None) -> List[sqlite3.Row]:
        if status:
            cur = self.conn.execute("SELECT * FROM bots WHERE status=? ORDER BY hostname", (status,))
        else:
            cur = self.conn.execute("SELECT * FROM bots ORDER BY hostname")
        return cur.fetchall()

    def heartbeat(self, bot_id: str) -> None:
        self.conn.execute(
            "UPDATE bots SET last_seen=strftime('%Y-%m-%dT%H:%M:%SZ','now'), status='idle' WHERE id=?",
            (bot_id,),
        )
        self.conn.commit()

    # ── tasks ──────────────────────────────────────────────────
    def queue_task(self, task: Task, issued_by: str = "operator") -> int:
        if self.kill_switch_engaged():
            raise RuntimeError("kill switch engaged — refusing to queue task")
        cur = self.conn.execute(
            "INSERT INTO tasks(bot_id, kind, payload, created_at, status) "
            "VALUES (?,?,?,?,?)",
            (task.bot_id, task.kind, task.payload, task.created_at, "queued"),
        )
        task_id = cur.lastrowid
        sig = hashlib.sha256(
            f"{task_id}:{task.bot_id}:{task.kind}:{task.payload}".encode()
        ).hexdigest()
        self.conn.execute(
            "INSERT INTO commands(task_id, issued_by, signature) VALUES (?,?,?)",
            (task_id, issued_by, sig),
        )
        self.conn.commit()
        return task_id

    def dispatch(self, bot_id: str) -> Optional[sqlite3.Row]:
        if self.kill_switch_engaged():
            return None
        cur = self.conn.execute(
            "SELECT * FROM tasks WHERE bot_id=? AND status='queued' ORDER BY id LIMIT 1",
            (bot_id,),
        )
        row = cur.fetchone()
        if not row:
            return None
        self.conn.execute(
            "UPDATE tasks SET status='sent', dispatched_at=strftime('%Y-%m-%dT%H:%M:%SZ','now') WHERE id=?",
            (row["id"],),
        )
        self.conn.commit()
        return self.conn.execute("SELECT * FROM tasks WHERE id=?", (row["id"],)).fetchone()

    def complete(self, task_id: int, bot_id: str, output: str, success: bool = True) -> None:
        self.conn.execute(
            "UPDATE tasks SET status=?, completed_at=strftime('%Y-%m-%dT%H:%M:%SZ','now') WHERE id=?",
            ("done" if success else "failed", task_id),
        )
        self.conn.execute(
            "INSERT INTO results(task_id, bot_id, output, success) VALUES (?,?,?,?)",
            (task_id, bot_id, output, 1 if success else 0),
        )
        self.conn.commit()

    def pending_tasks(self) -> List[sqlite3.Row]:
        cur = self.conn.execute(
            "SELECT * FROM tasks WHERE status IN ('queued','sent') ORDER BY id"
        )
        return cur.fetchall()

    def revoke_all_commands(self) -> int:
        cur = self.conn.execute("UPDATE commands SET revoked=1 WHERE revoked=0")
        self.conn.commit()
        return cur.rowcount

    # ── results ────────────────────────────────────────────────
    def results_for(self, bot_id: str) -> List[sqlite3.Row]:
        cur = self.conn.execute(
            "SELECT * FROM results WHERE bot_id=? ORDER BY received_at DESC",
            (bot_id,),
        )
        return cur.fetchall()

    def close(self) -> None:
        self.conn.close()
