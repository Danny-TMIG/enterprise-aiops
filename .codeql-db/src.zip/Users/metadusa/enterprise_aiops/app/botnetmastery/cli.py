from __future__ import annotations
import argparse, json, sys
from pathlib import Path

from app.botnetmastery.c2 import C2Server
from app.botnetmastery.simulation import Simulation


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="botnetmastery",
                                description="Defensive botnet C2 simulation")
    p.add_argument("--db", default="./data/botnet.db")
    p.add_argument("--bots", type=int, default=10)
    p.add_argument("--ticks", type=int, default=3)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--engage-kill-switch", action="store_true")
    a = p.parse_args(argv)

    Path(a.db).parent.mkdir(parents=True, exist_ok=True)
    srv = C2Server(a.db)

    if a.engage_kill_switch:
        srv.engage_kill_switch("cli flag")
        print("[kill switch engaged]")

    sim = Simulation(srv, seed=a.seed)
    sim.spawn(a.bots)
    sim.queue_broadcast("heartbeat", {"interval": 30})
    sim.queue_broadcast("inventory", {})

    for t in range(a.ticks):
        stats = sim.tick()
        print(json.dumps({"tick": t + 1, **stats}))

    print(json.dumps({
        "bots": len(sim.bots),
        "pending": len(srv.pending_tasks()),
        "kill_switch": srv.kill_switch_engaged(),
    }, indent=2))
    srv.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
