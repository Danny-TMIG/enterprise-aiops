from __future__ import annotations
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
import json, uuid


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


@dataclass
class Bot:
    id: str
    hostname: str
    os: str
    arch: str
    first_seen: str = field(default_factory=_now)
    last_seen: str = field(default_factory=_now)
    status: str = "idle"
    tags: List[str] = field(default_factory=list)

    @staticmethod
    def new(hostname: str, os: str, arch: str, tags: Optional[List[str]] = None) -> "Bot":
        return Bot(id=f"b-{uuid.uuid4().hex[:8]}", hostname=hostname,
                   os=os, arch=arch, tags=tags or ["sim"])

    def to_row(self) -> Dict[str, Any]:
        return {**asdict(self), "tags": json.dumps(self.tags)}


@dataclass
class Task:
    id: Optional[int]
    bot_id: str
    kind: str
    payload: str
    created_at: str = field(default_factory=_now)
    dispatched_at: Optional[str] = None
    completed_at: Optional[str] = None
    status: str = "queued"

    @staticmethod
    def new(bot_id: str, kind: str, payload: Dict[str, Any]) -> "Task":
        return Task(id=None, bot_id=bot_id, kind=kind, payload=json.dumps(payload))


@dataclass
class Command:
    id: Optional[int]
    task_id: int
    issued_by: str
    signature: str
    issued_at: str = field(default_factory=_now)
    revoked: int = 0


@dataclass
class Result:
    id: Optional[int]
    task_id: int
    bot_id: str
    output: str
    received_at: str = field(default_factory=_now)
    success: int = 1
