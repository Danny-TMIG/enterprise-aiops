from __future__ import annotations
import random
from typing import Dict, List

from app.botnetmastery.c2 import C2Server
from app.botnetmastery.models import Bot, Task


class Simulation:
    """
    Deterministic-ish discrete-event simulation of a botnet.

    Bots are simulated in-process. A bot tick:
      1. heartbeat
      2. pull one queued task
      3. produce a canned output
      4. report result

    No real commands are executed.
    """

    def __init__(self, server: C2Server, seed: int = 42):
        self.server = server
        self.rng = random.Random(seed)
        self.bots: List[Bot] = []

    # ── population ─────────────────────────────────────────────
    def spawn(self, n: int,
              oses=("linux", "windows", "darwin"),
              arches=("x86_64", "arm64")) -> None:
        for i in range(n):
            b = Bot.new(
                hostname=f"sim-{i:04d}",
                os=self.rng.choice(oses),
                arch=self.rng.choice(arches),
                tags=["sim", self.rng.choice(["lab", "dmz", "cloud"])],
            )
            self.server.register_bot(b)
            self.bots.append(b)

    # ── tasking ────────────────────────────────────────────────
    def queue_broadcast(self, kind: str, payload: Dict) -> int:
        n = 0
        for b in self.bots:
            self.server.queue_task(Task.new(b.id, kind, payload), issued_by="sim")
            n += 1
        return n

    # ── ticks ──────────────────────────────────────────────────
    def tick(self) -> Dict[str, int]:
        stats = {"heartbeats": 0, "dispatched": 0, "completed": 0, "skipped": 0}
        for b in self.bots:
            if self.server.kill_switch_engaged():
                stats["skipped"] += len(self.bots)
                break
            self.server.heartbeat(b.id)
            stats["heartbeats"] += 1
            task = self.server.dispatch(b.id)
            if not task:
                continue
            stats["dispatched"] += 1
            output = self._fake_output(task["kind"], task["payload"])
            self.server.complete(task["id"], b.id, output, success=True)
            stats["completed"] += 1
        return stats

    def _fake_output(self, kind: str, payload: str) -> str:
        # Canned, harmless outputs. No real execution.
        if kind == "heartbeat":
            return '{"ok":true,"interval":30}'
        if kind == "inventory":
            return '{"cpu":"sim","mem_mb":1024,"disk_gb":50}'
        if kind == "ping":
            return '{"ok":true,"rtt_ms":12}'
        return '{"ok":true,"echo":"' + kind + '"}'
