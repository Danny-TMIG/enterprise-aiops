import hashlib
import json
from pathlib import Path

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa


def sign_sbom() -> None:
    sbom_path = Path("dist/sbom.json")
    if not sbom_path.exists():
        Path("dist").mkdir(parents=True, exist_ok=True)
        sbom_path.write_text(json.dumps({"artifact": "dummy"}, indent=2))

    content = sbom_path.read_bytes()
    expected_digest = hashlib.sha256(content).digest()
    digest_hex = expected_digest.hex()

    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
    )
    public_key = private_key.public_key()

    signature_bytes = private_key.sign(
        expected_digest,
        padding.PSS(
            mgf=padding.MGF1(hashes.SHA256()),
            salt_length=padding.PSS.MAX_LENGTH,
        ),
        hashes.SHA256(),
    )

    pub_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    Path("dist/public_key.pem").write_bytes(pub_pem)

    sig_data = {
        "artifact": "dist/sbom.json",
        "algorithm": "sha256",
        "digest_hex": digest_hex,
        "signature_hex": signature_bytes.hex(),
        "signer": "enterprise_aiops-cosign-mock",
        "status": "cryptographically_signed",
    }

    Path("dist/sbom.json.sig").write_text(json.dumps(sig_data, indent=2))
    print("SBOM signed successfully.")

if __name__ == "__main__":
    sign_sbom()
