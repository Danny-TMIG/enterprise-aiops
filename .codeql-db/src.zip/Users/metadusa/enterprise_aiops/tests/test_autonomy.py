import pytest
from app.autonomy.decisions import Decision, DecisionEngine, Rule
from app.autonomy.healer import Healer, Remedy
from app.autonomy.watchdog import Probe, Watchdog
from app.autonomy.runtime import Runtime


def test_engine_fires_rule():
    e = DecisionEngine()
    e.add(Rule(
        name="always",
        condition=lambda o: True,
        action=lambda o: Decision(rule="always", action="noop"),
    ))
    ds = e.evaluate({})
    assert len(ds) == 1
    assert ds[0].rule == "always"


def test_engine_cooldown_suppresses_repeat():
    e = DecisionEngine()
    e.add(Rule(
        name="hot",
        condition=lambda o: True,
        action=lambda o: Decision(rule="hot", action="noop"),
        cooldown_s=60,
    ))
    assert len(e.evaluate({})) == 1
    assert len(e.evaluate({})) == 0


def test_engine_priority_order():
    e = DecisionEngine()
    e.add(Rule("low",  lambda o: True, lambda o: Decision("low",  "a"), priority=100))
    e.add(Rule("high", lambda o: True, lambda o: Decision("high", "a"), priority=1))
    ds = e.evaluate({})
    assert [d.rule for d in ds] == ["high", "low"]


def test_engine_swallows_rule_exception():
    e = DecisionEngine()
    def boom(_): raise RuntimeError("nope")
    e.add(Rule("boom", lambda o: True, boom))
    ds = e.evaluate({})
    assert ds[0].action == "noop"
    assert ds[0].severity == "warn"


def test_healer_applies_remedy():
    h = Healer()
    h.register(Remedy("noop", lambda p: {"ok": True}))
    r = h.apply("noop", {})
    assert r["ok"] is True


def test_healer_rate_limits():
    h = Healer()
    h.register(Remedy("limited", lambda p: {"ok": True}, max_calls_per_minute=2))
    h.apply("limited", {}); h.apply("limited", {})
    r = h.apply("limited", {})
    assert r["ok"] is False
    assert r["error"] == "rate limited"


def test_healer_unknown_remedy():
    h = Healer()
    r = h.apply("nope", {})
    assert r["ok"] is False


def test_watchdog_snapshot_and_step():
    e = DecisionEngine()
    e.add(Rule("always", lambda o: True, lambda o: Decision("always", "noop")))
    w = Watchdog(e, probes=[Probe("x", lambda: {"ok": True})])
    ds = w.step()
    assert len(ds) == 1
    assert w.last_observation()["x"] == {"ok": True}


def test_runtime_wires_policies():
    rt = Runtime()
    names = set(rt.engine.rules())
    assert "db_down" in names
    assert "error_rate_high" in names
    assert "memory_pressure" in names
    assert "kill_switch_engaged" in names


def test_runtime_step_returns_shape():
    rt = Runtime()
    out = rt.step()
    assert "observation" in out
    assert "decisions" in out
    assert "applied" in out
