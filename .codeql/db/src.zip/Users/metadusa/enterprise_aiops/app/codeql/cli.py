"""python3 -m app.codeql.cli {install|create|analyze|report|all}"""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path

from app.codeql.config import load_config
from app.codeql.runner import (
    cli_present, cli_version, install_cli, create_database, analyze,
)
from app.codeql.report import parse_sarif, summarize, render_markdown
from app.codeql.policy import load_policy, apply_policy


def _hdr(t: str) -> None:
    print("=" * 74)
    print("  " + t)
    print("=" * 74)


def _cmd_install(args) -> int:
    cfg = load_config()
    _hdr("CodeQL CLI")
    print(f"  home:    {cfg.codeql_home}")
    print(f"  bin:     {cfg.codeql_bin}")
    print(f"  present: {cli_present(cfg)}")
    if args.force or not cli_present(cfg):
        install_cli(cfg, force=args.force)
    print(f"  version: {cli_version(cfg)}")
    return 0


def _cmd_create(args) -> int:
    cfg = load_config()
    _hdr("CodeQL database")
    db = create_database(cfg, force=args.force)
    print(json.dumps(db.to_dict(), indent=2))
    return 0


def _cmd_analyze(args) -> int:
    cfg = load_config()
    _hdr("CodeQL analyze")
    if not cli_present(cfg):
        install_cli(cfg)
    db = create_database(cfg, force=args.force)
    print(json.dumps(db.to_dict(), indent=2))
    a = analyze(cfg, db, download=True)
    print(f"  exit_code: {a.exit_code}")
    print(f"  sarif:     {a.sarif_path}")
    if not a.ok:
        print(a.stderr[-2000:])
        return a.exit_code or 1
    return 0


def _cmd_report(args) -> int:
    cfg = load_config()
    sarif = Path(args.sarif) if args.sarif else cfg.sarif_dir / "results.sarif"
    _hdr(f"CodeQL report — {sarif}")
    report = parse_sarif(sarif)
    print(json.dumps(summarize(report), indent=2))
    md = render_markdown(report)
    out = cfg.repo_root / "docs" / "codeql.md"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(md)
    print(f"  wrote {out}")
    policy_doc = None
    pol_path = cfg.repo_root / ".codeql" / "policy.json"
    if pol_path.exists():
        policy_doc = json.loads(pol_path.read_text())
    policy = load_policy(policy_doc)
    decision = apply_policy(report, policy)
    print(f"  policy:   {json.dumps(decision.to_dict(), indent=2)}")
    return 0 if decision.ok else 1


def _cmd_all(args) -> int:
    rc = _cmd_install(args)
    if rc != 0:
        return rc
    rc = _cmd_analyze(args)
    if rc != 0:
        return rc
    return _cmd_report(args)


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="codeql")
    sub = p.add_subparsers(dest="cmd", required=True)

    for name, fn in (("install", _cmd_install),
                     ("create", _cmd_create),
                     ("analyze", _cmd_analyze),
                     ("report", _cmd_report),
                     ("all", _cmd_all)):
        sp = sub.add_parser(name)
        sp.add_argument("--force", action="store_true")
        sp.add_argument("--sarif", default=None)
        sp.set_defaults(fn=fn)

    args = p.parse_args(argv)
    return args.fn(args)


if __name__ == "__main__":
    sys.exit(main())
