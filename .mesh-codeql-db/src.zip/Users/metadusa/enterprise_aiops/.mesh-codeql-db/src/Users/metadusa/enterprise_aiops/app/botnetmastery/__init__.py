from app.botnetmastery.c2 import C2Server, Bot
