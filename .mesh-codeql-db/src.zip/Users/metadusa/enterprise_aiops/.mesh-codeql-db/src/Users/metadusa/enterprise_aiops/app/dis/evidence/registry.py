from __future__ import annotations
from typing import Any, Dict, List

from app.dis.evidence.base import EvidenceStore, EvidenceRecord
from app.dis.evidence.novafabric import NovaFabricStore
from app.dis.evidence.aar import AARStore


class EvidenceRegistry:
    def __init__(self) -> None:
        self.stores: Dict[str, EvidenceStore] = {
            "novafabric": NovaFabricStore(),
            "aar-alc":    AARStore(),
        }

    def list(self) -> Dict[str, Any]:
        return {n: {"available": s.available()}
                for n, s in self.stores.items()}

    def record(self, kind: str, subject: str,
               payload: Dict[str, Any]) -> Dict[str, Any]:
        r = EvidenceRecord(kind=kind, subject=subject, payload=payload)
        return {
            "record": r.to_dict(),
            "stores": [s.record(r) for s in self.stores.values()],
        }

    def record_to(self, store: str, kind: str, subject: str,
                  payload: Dict[str, Any]) -> Dict[str, Any]:
        s = self.stores.get(store)
        if not s:
            return {"status": "UNSUPPORTED", "store": store}
        r = EvidenceRecord(kind=kind, subject=subject, payload=payload)
        return s.record(r)
