from fastapi import FastAPI

app = FastAPI(title="enterprise_aiops")

@app.get("/")
def read_root():
    return {"status": "operational", "system": "enterprise_aiops"}
