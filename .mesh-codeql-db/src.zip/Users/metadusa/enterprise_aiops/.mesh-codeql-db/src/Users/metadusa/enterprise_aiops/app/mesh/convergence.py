import asyncio
from dataclasses import dataclass

@dataclass
class ConvergenceMetrics:
    achieved_value: float
    subsystem: str

class MeshConvergenceValidator:
    def __init__(self, default_timeout: float = 2.0, poll_interval: float = 0.01):
        self.default_timeout = default_timeout
        self.poll_interval = poll_interval

    async def assert_converges(self, probe_fn, expected: float, subsystem: str) -> ConvergenceMetrics:
        start_time = asyncio.get_event_loop().time()
        while (asyncio.get_event_loop().time() - start_time) < self.default_timeout:
            val = probe_fn()
            if val == expected:
                return ConvergenceMetrics(achieved_value=val, subsystem=subsystem)
            await asyncio.sleep(self.poll_interval)
        val = probe_fn()
        return ConvergenceMetrics(achieved_value=val, subsystem=subsystem)
