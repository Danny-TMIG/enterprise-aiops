from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List


@dataclass
class Node:
    id: str
    kind: str
    name: str
    file: str = ""
    line: int = 0
    extra: List[str] = field(default_factory=list)
    source: str = "ast"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "kind": self.kind, "name": self.name,
            "file": self.file, "line": self.line,
            "extra": self.extra, "source": self.source,
        }


@dataclass
class Edge:
    src: str
    dst: str
    kind: str

    def to_dict(self) -> Dict[str, Any]:
        return {"src": self.src, "dst": self.dst, "kind": self.kind}


class MeshGraph:
    def __init__(self) -> None:
        self.nodes: Dict[str, Node] = {}
        self.edges: List[Edge] = []

    def add(self, node: Node) -> None:
        self.nodes[node.id] = node

    def link(self, src: str, dst: str, kind: str) -> None:
        if src in self.nodes and dst in self.nodes and src != dst:
            self.edges.append(Edge(src, dst, kind))

    def by_kind(self, kind: str) -> List[Node]:
        return [n for n in self.nodes.values() if n.kind == kind]

    def search(self, q: str) -> List[Node]:
        q = q.lower()
        out: List[Node] = []
        for n in self.nodes.values():
            hay = (n.name + " " + n.file + " " + " ".join(n.extra)).lower()
            if q in hay:
                out.append(n)
        return out

    def stats(self) -> Dict[str, Any]:
        kinds: Dict[str, int] = {}
        for n in self.nodes.values():
            kinds[n.kind] = kinds.get(n.kind, 0) + 1
        return {
            "nodes": len(self.nodes),
            "edges": len(self.edges),
            "kinds": kinds,
        }

    def to_dict(self) -> Dict[str, Any]:
        return {
            "nodes": [n.to_dict() for n in self.nodes.values()],
            "edges": [e.to_dict() for e in self.edges],
            "stats": self.stats(),
        }
