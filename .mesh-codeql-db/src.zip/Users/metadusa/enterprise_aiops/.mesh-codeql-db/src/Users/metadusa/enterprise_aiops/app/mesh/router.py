"""Intent → mesh node routing.

Scores nodes against a free-text intent using token overlap, with a
small bias toward endpoints and agents (the execution surface).
"""
from __future__ import annotations
from typing import Any, Dict, List

from app.mesh.graph import MeshGraph

_BIAS = {"endpoint": 2, "agent": 2, "skill": 1, "capability": 0}


def _tokens(intent: str) -> List[str]:
    raw = intent.lower().replace("/", " ").replace(".", " ").replace("_", " ")
    return [t for t in raw.split() if len(t) >= 3]


def route(intent: str, graph: MeshGraph, limit: int = 20) -> List[Dict[str, Any]]:
    toks = _tokens(intent)
    if not toks:
        return []
    scored: List[tuple] = []
    for n in graph.nodes.values():
        if n.kind in ("module", "import"):
            continue
        hay = (n.name + " " + n.file + " " + " ".join(n.extra)).lower()
        score = sum(1 for t in toks if t in hay)
        if score == 0:
            continue
        score += _BIAS.get(n.kind, 0)
        scored.append((score, n))
    scored.sort(key=lambda x: (-x[0], x[1].kind, x[1].name))
    return [{"score": s, **n.to_dict()} for s, n in scored[:limit]]
