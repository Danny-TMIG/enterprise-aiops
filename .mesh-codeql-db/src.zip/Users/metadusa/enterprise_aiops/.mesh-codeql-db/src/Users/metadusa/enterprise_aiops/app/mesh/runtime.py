"""Mesh runtime — one process-wide instance."""
from __future__ import annotations
import os
from pathlib import Path
from typing import Any, Dict, Optional

from app.mesh.ast_scan import scan as ast_scan
from app.mesh.codeql_runner import run_codeql
from app.mesh.graph import MeshGraph, Node
from app.mesh.sarif import parse_sarif

_RUNTIME: Optional["MeshRuntime"] = None


class MeshRuntime:
    def __init__(self, root: Optional[str] = None) -> None:
        self.root = str(Path(root or os.getcwd()).resolve())
        self.graph = MeshGraph()
        self.codeql_ok = False
        self.codeql_reason = "not attempted"
        self.rebuild()

    def rebuild(self) -> Dict[str, Any]:
        self.graph = MeshGraph()

        # 1. AST scan (always)
        for n in ast_scan(self.root):
            self.graph.add(Node(
                id=n["id"], kind=n["kind"], name=n["name"],
                file=n["file"], line=n["line"],
                extra=n.get("extra", []), source="ast",
            ))

        # 2. CodeQL (best-effort)
        try:
            sarif = run_codeql(self.root)
            if sarif:
                for n in parse_sarif(sarif):
                    nid = f"cq:{n['kind']}:{n['name']}:{n['file']}:{n['line']}"
                    self.graph.add(Node(
                        id=nid, kind=n["kind"], name=n["name"],
                        file=n["file"], line=n["line"],
                        extra=n.get("extra", []), source="codeql",
                    ))
                self.codeql_ok = True
                self.codeql_reason = "ok"
            else:
                self.codeql_ok = False
                self.codeql_reason = "codeql unavailable or returned no sarif"
        except Exception as exc:  # noqa: BLE001
            self.codeql_ok = False
            self.codeql_reason = f"codeql error: {type(exc).__name__}"

        # 3. Link: node.file → module node (plane membership)
        module_by_file: Dict[str, str] = {}
        for n in self.graph.nodes.values():
            if n.kind == "module":
                module_by_file[n.file] = n.id
        for n in list(self.graph.nodes.values()):
            if n.kind in ("module",):
                continue
            mid = module_by_file.get(n.file)
            if mid:
                self.graph.link(mid, n.id, "contains")

        return self.graph.stats()

    def status(self) -> Dict[str, Any]:
        return {
            "root": self.root,
            "codeql_ok": self.codeql_ok,
            "codeql_reason": self.codeql_reason,
            "stats": self.graph.stats(),
        }


def get_mesh() -> MeshRuntime:
    global _RUNTIME
    if _RUNTIME is None:
        _RUNTIME = MeshRuntime()
    return _RUNTIME
