from dataclasses import dataclass, field
from typing import Dict, Any, List

@dataclass
class Axis:
    name: str
    weight: float = 1.0
    description: str = ""

@dataclass
class AxisScore:
    axis: str
    score: float
    details: Dict[str, Any] = field(default_factory=dict)

AXES = [
    Axis(name="security", weight=1.0, description="Security and isolation"),
    Axis(name="robustness", weight=1.0, description="Robustness and fault tolerance")
]

def score_subsystem(subsystem_name: str) -> Dict[str, float]:
    return {axis.name: 1.0 for axis in AXES}

def score_all() -> Dict[str, float]:
    return {axis.name: 1.0 for axis in AXES}
