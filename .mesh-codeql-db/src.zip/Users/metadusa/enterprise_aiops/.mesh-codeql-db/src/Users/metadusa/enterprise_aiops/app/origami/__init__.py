from app.origami.grammar import OrigamiGrammar
