"""Sharded long context.

A single 7B model on MLX carries ~32k tokens.  A "double-double"
context window is 4 shards of that size, combined via the grammar
so the effective prompt is roughly 4x longer without any single
inference exceeding the model's true limit.

Two modes:

  shard(text, n)         split into n overlapping chunks
  stitch(parts)          merge n outputs into one text with the
                         boundary markers intact
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class Shard:
    index: int
    text: str
    tokens_approx: int
    start_char: int
    end_char: int
    prefix: str = ""
    suffix: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {"index": self.index,
                "tokens_approx": self.tokens_approx,
                "start_char": self.start_char,
                "end_char": self.end_char,
                "prefix": self.prefix[:32],
                "suffix": self.suffix[-32:],
                "chars": len(self.text)}


@dataclass
class Stitched:
    parts: List[str]
    separator: str = "\n---\n"
    meta: Dict[str, Any] = field(default_factory=dict)

    def text(self) -> str:
        return self.separator.join(self.parts)

    def to_dict(self) -> Dict[str, Any]:
        return {"parts": len(self.parts),
                "chars": sum(len(p) for p in self.parts),
                "separator": self.separator,
                "meta": self.meta}


def _tok_approx(s: str) -> int:
    return max(1, len(s) // 4)


def shard(text: str, n: int, overlap: int = 64) -> List[Shard]:
    """Split into n overlapping shards of roughly equal size."""
    if n <= 1:
        return [Shard(0, text, _tok_approx(text), 0, len(text))]
    total = len(text)
    size = max(1, total // n)
    out: List[Shard] = []
    for i in range(n):
        start = max(0, i * size - (overlap if i > 0 else 0))
        end = total if i == n - 1 else min(total, (i + 1) * size + overlap)
        chunk = text[start:end]
        out.append(Shard(
            index=i, text=chunk,
            tokens_approx=_tok_approx(chunk),
            start_char=start, end_char=end,
            prefix=text[max(0, start - 8):start],
            suffix=text[end:end + 8],
        ))
    return out


def stitch(parts: List[str], separator: str = "\n---\n",
           meta: Optional[Dict[str, Any]] = None) -> Stitched:
    meta = meta or {}
    meta["stitched_at"] = "origami"
    meta["n_parts"] = len(parts)
    return Stitched(parts=list(parts), separator=separator, meta=meta)


@dataclass
class DoubleDouble:
    """Four shards, two merge levels.

    level 1: (0,1) -> A, (2,3) -> B
    level 2: (A,B) -> final

    Each level runs on the swarm independently, so the effective
    context is 4x a single worker's window while each inference
    stays inside one worker.
    """
    parts: List[str]
    sep: str = "\n---\n"

    def level1(self) -> List[str]:
        a = self.sep.join(self.parts[:2])
        b = self.sep.join(self.parts[2:])
        return [a, b]

    def level2(self) -> str:
        a, b = self.level1()
        return self.sep.join([a, b])

    def to_dict(self) -> Dict[str, Any]:
        return {"parts": len(self.parts),
                "chars": sum(len(p) for p in self.parts)}
