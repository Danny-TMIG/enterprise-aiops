class ProprietaryRegistry:
    def __init__(self):
        self.artifacts = {}

    def register(self, key: str, artifact: object):
        self.artifacts[key] = artifact

    def get(self, key: str):
        return self.artifacts.get(key)
