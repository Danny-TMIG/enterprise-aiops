"""Demonstrate the four primitives anchored to the live mesh.

The mesh supplies the subjects (nodes). The registry supplies the
records. The gate returns a Decision using the atlas's own
RESULT STATES.
"""
from __future__ import annotations
import hashlib, json, os, sys, tempfile, time
from pathlib import Path

from app.agency.primitives import Agency, License, Certification, Expertise
from app.agency.registry import Registry
from app.agency.gate import gate


def _h(*p: str) -> str:
    m = hashlib.sha256()
    for s in p:
        m.update(s.encode()); m.update(b"\x1f")
    return "sha256:" + m.hexdigest()


def _live_mesh_nodes(limit: int = 6):
    try:
        from app.mesh.runtime import get_mesh
        m = get_mesh()
        return list(m.graph.nodes.values())[:limit]
    except Exception as e:
        print(f"  ! mesh unavailable: {e}")
        return []


def main() -> int:
    # use a scratch registry so the demo is idempotent
    scratch = Path(tempfile.mkdtemp(prefix="agency_")) / "registry.jsonl"
    reg = Registry(scratch)

    nodes = _live_mesh_nodes()
    print(f"── mesh subjects ({len(nodes)}) ──")
    for n in nodes:
        print(f"  {n.id:40s} kind={getattr(n,'kind','?')}")

    subjects = [n.id for n in nodes] or ["agent:demo-0", "agent:demo-1"]

    # Register one fully-qualified subject and three under-qualified ones.
    s_ok = subjects[0]
    reg.append(Agency(subject=s_ok, scope="code.write",
                      authority="org:acme", granted_by="governance:root",
                      evidence_hash=_h("grant", s_ok, "code.write")))
    reg.append(License(subject=s_ok, domain="repo.enterprise_aiops",
                       jurisdiction="org:acme", terms="read-write, no-push",
                       issued_by="governance:root",
                       evidence_hash=_h("license", s_ok, "repo.enterprise_aiops")))
    reg.append(Certification(subject=s_ok, standard="OWASP-ASVS",
                             version="4.0.3", level="L2",
                             issued_by="assessor:owasp",
                             evidence_hash=_h("cert", s_ok, "OWASP-ASVS")))
    e = Expertise(subject=s_ok, domain="repo.enterprise_aiops")
    for i, ok in enumerate([True, True, True, False, True, True]):
        e.record(ok, _h("run", s_ok, str(i)))
    reg.append(e)

    if len(subjects) > 1:
        s_no_agency = subjects[1]
        # has license, no agency
        reg.append(License(subject=s_no_agency, domain="repo.enterprise_aiops",
                           jurisdiction="org:acme", terms="read-only",
                           issued_by="governance:root",
                           evidence_hash=_h("license", s_no_agency, "repo")))
    if len(subjects) > 2:
        s_expired = subjects[2]
        reg.append(Agency(subject=s_expired, scope="code.write",
                          authority="org:acme", granted_by="governance:root",
                          evidence_hash=_h("grant", s_expired, "code.write"),
                          expires_at="2020-01-01T00:00:00Z"))

    print()
    print("── gate queries ──")
    cases = [
        (s_ok, "code.write", dict(scope="code.write",
                                  domain="repo.enterprise_aiops",
                                  jurisdiction="org:acme",
                                  required_standard="OWASP-ASVS",
                                  required_level="L2",
                                  min_expertise=0.5)),
        (subjects[0], "code.write", dict(scope="code.write",
                                         domain="prod.eu-west-1",
                                         jurisdiction="org:acme")),
        (subjects[1] if len(subjects) > 1 else s_ok, "code.write",
         dict(scope="code.write",
              domain="repo.enterprise_aiops",
              jurisdiction="org:acme")),
        (subjects[2] if len(subjects) > 2 else s_ok, "code.write",
         dict(scope="code.write",
              domain="repo.enterprise_aiops",
              jurisdiction="org:acme")),
    ]

    ok = 0
    for subj, cap, kw in cases:
        d = gate(subj, cap, registry=reg, **kw)
        mark = "✓" if d.state == "PASS" else "·"
        print(f"  [{mark}] {d.state:22s} {subj[:24]:24s} {d.reason[:60]}")
        if d.state == "PASS":
            ok += 1

    print()
    print(f"  passed gates: {ok}/{len(cases)}")
    print(f"  registry:     {scratch}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
