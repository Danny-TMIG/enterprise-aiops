class Decision:
    def __init__(self, name: str = "", action: str = "", metadata: dict = None, **kwargs):
        self.name = name
        self.action = action
        self.metadata = metadata or {}
        for k, v in kwargs.items():
            setattr(self, k, v)

class Rule:
    def __init__(self, *args, name: str = "", condition=None, action=None, priority: int = 0, **kwargs):
        self.name = name or kwargs.get("id", "rule")
        self.condition = condition or (lambda ctx: True)
        self.action = action or (lambda ctx: None)
        self.priority = priority or kwargs.get("weight", 0)
        for k, v in kwargs.items():
            setattr(self, k, v)

class DecisionEngine:
    def __init__(self, **kwargs):
        self.rules = []
        for k, v in kwargs.items():
            setattr(self, k, v)

    def add_rule(self, rule: Rule):
        self.rules.append(rule)

    def evaluate(self, context: dict):
        sorted_rules = sorted(self.rules, key=lambda r: getattr(r, 'priority', 0), reverse=True)
        for rule in sorted_rules:
            try:
                if callable(rule.condition) and rule.condition(context):
                    if callable(rule.action):
                        return rule.action(context)
                    return rule.action
            except Exception:
                continue
        return None
