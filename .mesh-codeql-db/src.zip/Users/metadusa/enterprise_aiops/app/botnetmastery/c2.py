class Bot:
    def __init__(self, bot_id: str, os_type: str, arch: str, **kwargs):
        self.bot_id = bot_id
        self.os_type = os_type
        self.arch = arch
        for k, v in kwargs.items():
            setattr(self, k, v)

    @classmethod
    def new(cls, bot_id: str, os_type: str, arch: str, **kwargs):
        return cls(bot_id=bot_id, os_type=os_type, arch=arch, **kwargs)

class C2Server:
    def __init__(self, db_path: str = ":memory:", **kwargs):
        self.db_path = db_path
        self.bots = {}
        self.nodes = {}
        self.tasks = []
        self.results = {}
        self.kill_switch_active = False
        for k, v in kwargs.items():
            setattr(self, k, v)

    def register_node(self, node_id: str, metadata: dict = None):
        self.nodes[node_id] = metadata or {}

    def register_bot(self, bot: Bot):
        self.bots[bot.bot_id] = bot

    def queue_task(self, task: str):
        if self.kill_switch_active:
            raise RuntimeError("Kill switch active")
        self.tasks.append(task)

    def dispatch(self):
        if self.kill_switch_active:
            return []
        t = self.tasks.copy()
        self.tasks.clear()
        return t

    def complete_task(self, bot_id: str, task_id: str, result: str):
        self.results[task_id] = result

    def set_kill_switch(self, active: bool):
        self.kill_switch_active = active

    def close(self):
        pass

    def broadcast(self, command: str):
        return {bot_id: f"ACK:{command}" for bot_id in self.bots}
