from __future__ import annotations
from typing import Any, Dict, Optional

from app.dis.models.registry import get_registry
from app.dis.orchestration.registry import OrchestrationRegistry
from app.dis.verification.registry import VerificationRegistry
from app.dis.scan.registry import ScanRegistry
from app.dis.evidence.registry import EvidenceRegistry
from app.dis.protocols.mcp import MCPServer, MCPTool
from app.dis.protocols.a2a import A2AServer, AgentCard


class DisRuntime:
    def __init__(self) -> None:
        self.models = get_registry()
        self.orchestration = OrchestrationRegistry()
        self.verification = VerificationRegistry()
        self.scan = ScanRegistry()
        self.evidence = EvidenceRegistry()
        self.mcp = self._build_mcp()
        self.a2a = self._build_a2a()

    # ── MCP surface ─────────────────────────────────────────────
    def _build_mcp(self) -> MCPServer:
        srv = MCPServer()
        srv.register(MCPTool(
            name="mesh.models.status",
            description="List model providers and task routes",
            input_schema={"type": "object", "properties": {}},
            fn=lambda a: self.models.status(),
        ))
        srv.register(MCPTool(
            name="mesh.prove",
            description="Run a prover (leandojo/prove2me/lean4agent/lean4-kernel)",
            input_schema={
                "type": "object",
                "properties": {"prover": {"type": "string"},
                               "statement": {"type": "string"}},
                "required": ["prover", "statement"],
            },
            fn=lambda a: self.verification.prove(
                a["prover"], a["statement"], a.get("context") or {}
            ).to_dict(),
        ))
        srv.register(MCPTool(
            name="mesh.scan",
            description="Run scanners (codeql/codacy) against the repo",
            input_schema={
                "type": "object",
                "properties": {"root": {"type": "string"}},
            },
            fn=lambda a: [r.to_dict()
                          for r in self.scan.scan_all(a.get("root") or ".")],
        ))
        srv.register(MCPTool(
            name="mesh.evidence.record",
            description="Record evidence into NovaFabric + AAR/ALC",
            input_schema={
                "type": "object",
                "properties": {"kind": {"type": "string"},
                               "subject": {"type": "string"},
                               "payload": {"type": "object"}},
                "required": ["kind", "subject"],
            },
            fn=lambda a: self.evidence.record(
                a["kind"], a["subject"], a.get("payload") or {}
            ),
        ))
        return srv

    # ── A2A surface ─────────────────────────────────────────────
    def _build_a2a(self) -> A2AServer:
        card = AgentCard(
            name="tmig-mesh",
            description="Verification backend for external orchestrators",
            capabilities=["verification", "proving", "scanning", "evidence"],
        )
        srv = A2AServer(card=card)

        @srv.skill("verify", "Verify a claim with local verifiers")
        def _verify(params: Dict[str, Any]) -> Dict[str, Any]:
            from app.dis.orchestration.base import VerificationClaim
            claim = VerificationClaim(
                claim=params.get("claim", ""),
                subject=params.get("subject", ""),
                evidence=params.get("evidence") or [],
            )
            vendor = params.get("vendor") or "microsoft"
            return self.orchestration.verify(vendor, claim).to_dict()

        @srv.skill("prove", "Run a prover on a statement")
        def _prove(params: Dict[str, Any]) -> Dict[str, Any]:
            return self.verification.prove(
                params.get("prover", "prove2me"),
                params.get("statement", ""),
                params.get("context") or {},
            ).to_dict()

        @srv.skill("scan", "Run scanners against a root")
        def _scan(params: Dict[str, Any]) -> Dict[str, Any]:
            root = params.get("root") or "."
            return [r.to_dict() for r in self.scan.scan_all(root)]

        @srv.skill("evidence", "Record evidence")
        def _evidence(params: Dict[str, Any]) -> Dict[str, Any]:
            return self.evidence.record(
                params.get("kind", "note"),
                params.get("subject", ""),
                params.get("payload") or {},
            )

        return srv

    # ── status ──────────────────────────────────────────────────
    def status(self) -> Dict[str, Any]:
        return {
            "models": self.models.status(),
            "orchestration": self.orchestration.list(),
            "verification": self.verification.list(),
            "scan": self.scan.list(),
            "evidence": self.evidence.list(),
            "protocols": {
                "mcp": {"tools": list(self.mcp.tools.keys())},
                "a2a": {"skills": [s["id"] for s in self.a2a.card.skills]},
            },
        }


_RT: Optional[DisRuntime] = None


def get_dis() -> DisRuntime:
    global _RT
    if _RT is None:
        _RT = DisRuntime()
    return _RT
