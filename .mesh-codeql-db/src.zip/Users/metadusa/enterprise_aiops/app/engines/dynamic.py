"""Dynamic difficulty controller.

Per kind:
    if mean_rate > high_threshold:  raise difficulty
    if mean_rate < low_threshold:   lower difficulty

The thresholds and step are configurable. The controller keeps
a history so you can see the difficulty trajectory.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List


LEVELS = ("easy", "medium", "hard")


@dataclass
class DifficultyState:
    kind: str
    level: str = "medium"

    def _idx(self) -> int:
        return LEVELS.index(self.level)

    def raise_(self) -> None:
        i = self._idx()
        if i < len(LEVELS) - 1:
            self.level = LEVELS[i + 1]

    def lower(self) -> None:
        i = self._idx()
        if i > 0:
            self.level = LEVELS[i - 1]


@dataclass
class Controller:
    high: float = 0.85
    low: float = 0.25
    state: Dict[str, DifficultyState] = field(default_factory=dict)
    history: List[Dict[str, str]] = field(default_factory=list)

    def initialise(self, kinds) -> None:
        for k in kinds:
            self.state[k] = DifficultyState(kind=k, level="medium")
        self.history.append({k: s.level for k, s in self.state.items()})

    def step(self, rate_by_kind: Dict[str, float]) -> Dict[str, str]:
        for k, r in rate_by_kind.items():
            s = self.state.get(k)
            if s is None:
                continue
            if r >= self.high:
                s.raise_()
            elif r <= self.low:
                s.lower()
        snap = {k: s.level for k, s in self.state.items()}
        self.history.append(snap)
        return snap

    def current(self) -> Dict[str, str]:
        return {k: s.level for k, s in self.state.items()}

    def to_dict(self) -> dict:
        return {"current": self.current(), "history": self.history}
