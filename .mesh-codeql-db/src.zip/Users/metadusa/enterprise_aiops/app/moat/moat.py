"""The moat mesh. Composite graphs computed from live signals."""
from __future__ import annotations
import json, os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List


COMPOSITE_GRAPHS = ["C_g", "S_g", "E_g", "P_g", "Q_g", "K_g", "X_h"]
HISTORY_PATH = Path("./data/moat_history.json")


@dataclass
class MoatEquation:
    c_g: Dict[str, Any] = field(default_factory=dict)
    s_g: Dict[str, Any] = field(default_factory=dict)
    e_g: Dict[str, Any] = field(default_factory=dict)
    p_g: Dict[str, Any] = field(default_factory=dict)
    q_g: Dict[str, Any] = field(default_factory=dict)
    k_g: Dict[str, Any] = field(default_factory=dict)
    x_h: Dict[str, Any] = field(default_factory=dict)

    def factors(self) -> Dict[str, float]:
        return {k: _scalar(getattr(self, k.lower()))
                for k in COMPOSITE_GRAPHS}

    def product(self) -> float:
        p = 1.0
        for v in self.factors().values():
            p *= v
        return round(p, 8)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "factors": self.factors(),
            "product": self.product(),
            "graphs": {k: getattr(self, k.lower())
                       for k in COMPOSITE_GRAPHS},
        }


def _scalar(d: Dict[str, Any]) -> float:
    if not d:
        return 0.0
    if "_score" in d:
        try:
            return max(0.0, min(1.0, float(d["_score"])))
        except Exception:
            pass
    n = 0
    for v in d.values():
        if isinstance(v, (int, float)):
            n += 1
        elif isinstance(v, (list, tuple, set)):
            n += len(v)
        elif isinstance(v, dict):
            n += len(v)
    return 1.0 - 1.0 / (1.0 + n)


def _safe(fn: Callable[[], Dict[str, Any]]) -> Dict[str, Any]:
    try:
        r = fn()
        return r if isinstance(r, dict) else {}
    except Exception:
        return {}


def _load_history() -> Dict[str, Any]:
    if HISTORY_PATH.exists():
        try:
            return json.loads(HISTORY_PATH.read_text())
        except Exception:
            pass
    return {"runs": [], "merged": 0}


def _save_history(h: Dict[str, Any]) -> None:
    HISTORY_PATH.parent.mkdir(parents=True, exist_ok=True)
    HISTORY_PATH.write_text(json.dumps(h, indent=2, default=str))


def record_run(proof_object: Dict[str, Any], merged: bool = False) -> None:
    """Persist one completed Seed run so the moat sees it."""
    h = _load_history()
    h["runs"].append({
        "id": proof_object.get("id"),
        "kernel_status": (proof_object.get("kernel") or {}).get("status"),
        "cpvo": (proof_object.get("cpvo") or {}).get("cpvo_usd"),
    })
    if merged:
        h["merged"] = h.get("merged", 0) + 1
    _save_history(h)


class MoatMesh:
    def __init__(self) -> None:
        self.equation = MoatEquation()

    def refresh(self) -> "MoatMesh":
        self.equation = MoatEquation(
            c_g=self._capability(),
            s_g=self._skill(),
            e_g=self._evidence(),
            p_g=self._provenance(),
            q_g=self._qualification(),
            k_g=self._knowledge(),
            x_h=self._execution(),
        )
        return self

    def _capability(self) -> Dict[str, Any]:
        def go():
            from app.mesh.runtime import get_mesh
            st = get_mesh().graph.stats()
            n = st.get("nodes", 0)
            return {"nodes": n, "edges": st.get("edges", 0),
                    "_score": min(1.0, n / 1000.0)}
        return _safe(go)

    def _skill(self) -> Dict[str, Any]:
        def go():
            from app.topos.skills import SIGNATURE
            return {"count": SIGNATURE["count"],
                    "languages": len(SIGNATURE["languages"]),
                    "algorithms": len(SIGNATURE["algorithms"]),
                    "_score": min(1.0, SIGNATURE["count"] / 300.0)}
        return _safe(go)

    def _evidence(self) -> Dict[str, Any]:
        def go():
            from app.dis.evidence.registry import EvidenceRegistry
            stores = list(EvidenceRegistry().stores.keys())
            # the SBOM + signature are themselves real evidence
            sbom = Path("SBOM.json").exists()
            sig = Path("SBOM.sig").exists()
            bonus = 0.4 if (sbom and sig) else 0.0
            return {"stores": stores, "sbom": sbom, "sig": sig,
                    "_score": min(1.0, 0.5 + bonus)}
        return _safe(go)

    def _provenance(self) -> Dict[str, Any]:
        def go():
            # in-memory Seed runs + persisted history
            from app.seed.runtime import get_seed
            runs = get_seed().runs
            mem = sum(1 for w in runs.values() if w.proof_object is not None)
            h = _load_history()
            hist = len(h.get("runs", []))
            total = mem + hist
            return {"in_memory": mem, "persisted": hist,
                    "_score": min(1.0, total / 3.0) if total else 0.0}
        return _safe(go)

    def _qualification(self) -> Dict[str, Any]:
        def go():
            from app.dis.verification.registry import VerificationRegistry
            provers = VerificationRegistry().provers
            avail = [n for n, p in provers.items() if p.available()]
            # proprietary objects count as qualifiers too
            from app.proprietary.registry import ProprietaryRegistry
            props = ProprietaryRegistry().objects
            prop_real = sum(1 for o in props.values() if o.is_real())
            num = len(avail) + prop_real
            den = len(provers) + len(props)
            return {"provers": list(provers.keys()),
                    "available": avail,
                    "proprietary": prop_real,
                    "_score": num / max(1, den)}
        return _safe(go)

    def _knowledge(self) -> Dict[str, Any]:
        def go():
            from app.topos.runtime import get_topos
            st = get_topos().T.stats()
            o = st.get("objects", 0)
            return {"objects": o, "morphisms": st.get("morphisms", 0),
                    "_score": min(1.0, o / 50.0)}
        return _safe(go)

    def _execution(self) -> Dict[str, Any]:
        def go():
            from app.seed.runtime import get_seed
            runs = get_seed().runs
            mem_merged = sum(1 for w in runs.values()
                             if w.state.value in ("DELIVERED", "MERGED"))
            h = _load_history()
            hist_merged = h.get("merged", 0)
            total = mem_merged + hist_merged
            return {"in_memory": mem_merged,
                    "persisted": hist_merged,
                    "_score": min(1.0, total / 3.0)}
        return _safe(go)

    def to_dict(self) -> Dict[str, Any]:
        return self.equation.to_dict()


def merge_moat(*meshes: MoatMesh) -> MoatMesh:
    out = MoatMesh()
    if not meshes:
        return out
    factors = {k: 0.0 for k in COMPOSITE_GRAPHS}
    for m in meshes:
        for k, v in m.equation.factors().items():
            factors[k] = max(factors[k], v)
    out.equation = MoatEquation(
        c_g={"_score": factors["C_g"]},
        s_g={"_score": factors["S_g"]},
        e_g={"_score": factors["E_g"]},
        p_g={"_score": factors["P_g"]},
        q_g={"_score": factors["Q_g"]},
        k_g={"_score": factors["K_g"]},
        x_h={"_score": factors["X_h"]},
    )
    return out
