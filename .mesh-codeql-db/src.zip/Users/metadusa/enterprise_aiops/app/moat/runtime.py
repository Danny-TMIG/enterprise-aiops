from __future__ import annotations
from pathlib import Path
from typing import Any, Dict, Optional

from app.moat.axes import score_all
from app.moat.merge import merge_set
from app.moat.moat import MoatMesh


class MoatRuntime:
    def __init__(self, root: Optional[str] = None) -> None:
        self.root = Path(root or ".").resolve()

    def score(self, scope: str = "app") -> Dict[str, Any]:
        scores = score_all(self.root, scope=scope)
        merged = merge_set(scores)

        # system-measured axes (event counts, not source greps)
        E_sys = self._measure_e(scores)
        X_sys = self._measure_x()
        V_sys = self._measure_v()

        moat_grep = merged.moat
        moat_sys = round(E_sys * (X_sys ** 3) * (V_sys ** 2), 8)

        return {
            "scope": scope,
            "subsystems": len(scores),
            "axes": merged.axes,                          # per-file greps
            "moat_3axis_grep": moat_grep,                 # grep product
            "axes_system": {                              # event measures
                "exists": round(E_sys, 6),
                "real": round(X_sys, 6),
                "verified": round(V_sys, 6),
            },
            "moat_3axis": moat_sys,                       # system product
            "edges": [e.to_dict() for e in merged.edges][:200],
        }

    def _measure_e(self, scores) -> float:
        if not scores:
            return 0.0
        return sum(1 for s in scores if s.e > 0) / len(scores)

    def _measure_x(self) -> float:
        try:
            from app.reality.probe import probe_reality
            return probe_reality().score()["reality_fraction"]
        except Exception:
            return 0.0

    def _measure_v(self) -> float:
        try:
            from app.seed.counter import stats
            return stats()["v"]
        except Exception:
            return 0.0

    def mesh(self, scope: str = "app") -> Dict[str, Any]:
        scored = self.score(scope=scope)
        mesh = MoatMesh().refresh()
        mesh_dict = mesh.to_dict()

        a = scored["moat_3axis"]
        b = mesh_dict["product"]
        if a <= 0.0 or b <= 0.0:
            merged = 0.0
        else:
            merged = round((a ** 0.5) * (b ** 0.5), 8)

        return {"repo": scored, "composite": mesh_dict,
                "merged_moat": merged}

    def status(self) -> Dict[str, Any]:
        try:
            return self.mesh(scope="app")
        except Exception as exc:  # noqa: BLE001
            return {"error": type(exc).__name__,
                    "scope": "app", "merged_moat": 0.0}


_RT: Optional[MoatRuntime] = None


def get_moat() -> MoatRuntime:
    global _RT
    if _RT is None:
        _RT = MoatRuntime()
    return _RT
