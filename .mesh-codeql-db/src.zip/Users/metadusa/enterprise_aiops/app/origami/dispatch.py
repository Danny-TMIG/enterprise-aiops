"""Dispatch with per-leaf context, sanitized identifiers, preserved
body indentation, and multi-function/test support.

No sheaf. No opens. Just a state machine that holds lists.
"""
from __future__ import annotations
import re
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from app.origami.grammar import WeightedGrammar, expand
from app.origami.swarm import Swarm
import importlib as _il
_co = _il.import_module('app.origami.coalesce')


@dataclass
class DispatchResult:
    grammar_name: str
    seed: int
    intent: str
    leaves: int
    filled: int
    terminals: List[str]
    text: str
    tree: Dict[str, Any]
    code: str = ""
    swarm: Optional[Dict[str, Any]] = None
    sections: Optional[Dict[str, Any]] = None
    cocycle_ok: bool = False
    violations: Optional[List[str]] = None

    def to_dict(self) -> Dict[str, Any]:
        return {"grammar": self.grammar_name, "seed": self.seed,
                "intent": self.intent, "leaves": self.leaves,
                "filled": self.filled, "code_chars": len(self.code),
                "cocycle_ok": self.cocycle_ok,
                "violations": self.violations or [],
                "swarm": self.swarm}


_FENCE_RE = re.compile(r"```[a-zA-Z]*\s*\n?(.*?)```", re.DOTALL)
_DEF_RE = re.compile(
    r"^\s*def\s+\w+\s*\([^)]*\)\s*(?:->\s*[^:]+)?\s*:\s*", re.MULTILINE)


def clean_code(text: str) -> str:
    """Strip fences (matched or not) and any def prefix.
    Do NOT touch indentation."""
    s = text.rstrip()
    m = _FENCE_RE.search(s)
    if m:
        s = m.group(1)
    # drop any residual fence lines (unmatched ```
    kept = []
    for ln in s.splitlines():
        if ln.strip().startswith("```"):
            continue
        kept.append(ln)
    s = "\n".join(kept)
    s = _DEF_RE.sub("", s)
    return s


def _common_indent(lines: List[str]) -> int:
    """Minimum leading space count over non-empty lines."""
    indents = []
    for ln in lines:
        if not ln.strip():
            continue
        n = len(ln) - len(ln.lstrip())
        indents.append(n)
    return min(indents) if indents else 0


def rebase_body(text: str, base: int = 4) -> List[str]:
    """Take a body from the model, strip its common indent, and
    add `base` spaces to every non-empty line. Preserves relative
    structure inside the body (for/if/with blocks)."""
    lines = text.splitlines()
    cut = _common_indent(lines)
    out: List[str] = []
    for ln in lines:
        if not ln.strip():
            out.append("")
            continue
        stripped = ln[cut:] if len(ln) >= cut else ln.lstrip()
        out.append(" " * base + stripped)
    return out


# ── context routing ───────────────────────────────────────────
def _context(nt: str, intent: str, funcs: List[Dict[str, Any]],
             tests: List[Dict[str, Any]], mod_doc: str) -> List[str]:
    parts: List[str] = []
    if intent:
        parts.append("Intent: " + intent)
    if nt == "Imports":
        if mod_doc:
            parts.append("Doc: " + mod_doc[:60])
    elif nt == "FuncName":
        if funcs:
            parts.append("Used: " + ", ".join(f["name"] for f in funcs[-3:]))
    elif nt == "Params":
        if funcs and "name" in funcs[-1]:
            parts.append("Function: " + funcs[-1]["name"])
    elif nt == "Ret":
        if funcs and "name" in funcs[-1]:
            f = funcs[-1]
            parts.append(f"Function: {f.get('name','')}({f.get('params','')})")
    elif nt == "FDoc":
        if funcs and "name" in funcs[-1]:
            f = funcs[-1]
            parts.append(f"Function: {f.get('name','')}({f.get('params','')})"
                         f" -> {f.get('ret','')}")
    elif nt == "FBody":
        if funcs and "name" in funcs[-1]:
            f = funcs[-1]
            parts.append(f"Function: {f.get('name','')}({f.get('params','')})"
                         f" -> {f.get('ret','')}")
    elif nt == "TName":
        if funcs:
            parts.append("Functions: " + ", ".join(f["name"] for f in funcs))
    elif nt == "TBody":
        if funcs:
            f = funcs[-1]
            parts.append(f"Testing: {f.get('name','')} -> {f.get('ret','')}")
    return parts


def _build_prompt(nt: str, parts: List[str], payload: str) -> str:
    if parts:
        return "\n".join(parts) + "\n\n" + payload
    return payload


# ── kind inference ────────────────────────────────────────────
def _kind(payload: str) -> str:
    t = payload.lower()
    if "module docstring" in t or "docstring for the module" in t:
        return "mod_doc"
    if "import lines" in t:
        return "imports"
    if "python function name" in t:
        return "func_name"
    if "parameter list" in t:
        return "params"
    if "return type annotation" in t:
        return "ret"
    if "docstring for the function" in t:
        return "fdoc"
    if "function body" in t:
        return "fbody"
    if "test name" in t:
        return "test_name"
    if "assert statement" in t:
        return "test_body"
    return "text"


# ── assembly ──────────────────────────────────────────────────
def assemble(intent: str, mod_doc: str, imports: str,
             funcs: List[Dict[str, Any]],
             tests: List[Dict[str, Any]]) -> str:
    dq3 = '"' * 3
    sq3 = "'" * 3
    out: List[str] = []

    doc = (mod_doc or "").strip().replace(dq3, sq3)
    if doc:
        out.append(dq3 + doc + dq3)
        out.append("")

    imp = (imports or "").strip()
    if imp:
        out.append(imp)
        out.append("")
    out.append("from __future__ import annotations")
    out.append("")

    seen_names = set()
    deduped: List[Dict[str, Any]] = []
    for f in funcs:
        n = f.get("name") or "fn"
        if n in seen_names:
            continue
        seen_names.add(n)
        deduped.append(f)
    for f in deduped:
        name = f.get("name") or "fn"
        params = f.get("params") or ""
        ret = f.get("ret") or "None"
        out.append(f"def {name}({params}) -> {ret}:")
        fdoc = (f.get("fdoc") or "").strip().replace(dq3, sq3)
        if fdoc:
            out.append("    " + dq3 + fdoc + dq3)
        body = f.get("body") or "pass"
        for ln in _co.indent(body, spaces=4):
            out.append(ln)
        out.append("")

    for t in tests:
        name = t.get("name") or "test_fn"
        out.append(f"def {name}() -> None:")
        body = t.get("body") or "assert True"
        for ln in _co.indent(body, spaces=4):
            out.append(ln)
        out.append("")

    code = "\n".join(out).rstrip() + "\n"

    # post-assembly name resolution
    try:
        from app.origami.resolve import resolve, resolve_tests
        code = resolve(code)
        code = resolve_tests(code)
    except Exception:
        pass

    return code


# ── the dispatch loop ─────────────────────────────────────────
def dispatch(grammar: WeightedGrammar, swarm: Swarm, intent: str = "",
             seed: int = 42, max_depth: int = 10,
             max_tokens: int = 256, system: Optional[str] = None
             ) -> DispatchResult:
    d = expand(grammar, max_depth=max_depth, seed=seed)
    leaves = d["leaves"]

    mod_doc = ""
    imports = ""
    funcs: List[Dict[str, Any]] = []
    tests: List[Dict[str, Any]] = []
    cur_func: Dict[str, Any] = {}
    cur_test: Dict[str, Any] = {}
    worker_log: List[Any] = []
    filled_map: Dict[int, str] = {}

    for leaf in leaves:
        nt = leaf["nt"]
        payload = leaf.get("payload_prompt")
        if not payload:
            filled_map[leaf["index"]] = leaf["leaf"]
            continue

        kind = _kind(payload)

        # rotate state
        if kind == "func_name" and cur_func:
            funcs.append(cur_func)
            cur_func = {}
        if kind == "test_name" and cur_test:
            tests.append(cur_test)
            cur_test = {}
        if kind == "func_name":
            cur_func = {}
        if kind == "test_name":
            cur_test = {}

        parts = _context(kind, intent, funcs + ([cur_func] if cur_func else []),
                         tests + ([cur_test] if cur_test else []), mod_doc)
        if kind in ("fbody", "test_body"):
            parts.append(
                "Indent rule: the FIRST line has no leading spaces. "
                "Lines inside for/if/while/with/try blocks are indented "
                "by exactly 4 more spaces. No markdown fences. No "
                "triple backticks."
            )
        prompt = _build_prompt(kind, parts, payload)
        r = swarm.run_one(0, prompt, system=system, max_tokens=max_tokens)
        val = r.text
        worker_log.append(r)

        if kind == "mod_doc":
            mod_doc = _co.identifier(val) if not val.strip() else val.strip()
            filled_map[leaf["index"]] = mod_doc
        elif kind == "imports":
            imports = _co.imports(val)
            filled_map[leaf["index"]] = imports
        elif kind == "func_name":
            cur_func["name"] = _co.identifier(val)
            filled_map[leaf["index"]] = cur_func["name"]
        elif kind == "params":
            cur_func["params"] = _co.params(val)
            filled_map[leaf["index"]] = cur_func["params"]
        elif kind == "ret":
            cur_func["ret"] = _co.ret(val)
            filled_map[leaf["index"]] = cur_func["ret"]
        elif kind == "fdoc":
            cur_func["fdoc"] = _co.canonical_text(val)
            filled_map[leaf["index"]] = cur_func["fdoc"]
        elif kind == "fbody":
            cur_func["body"] = _co.canonical_body(val)
            filled_map[leaf["index"]] = cur_func["body"]
        elif kind == "test_name":
            cur_test["name"] = _co.test_identifier(val)
            filled_map[leaf["index"]] = cur_test["name"]
        elif kind == "test_body":
            cur_test["body"] = _co.canonical_body(val)
            filled_map[leaf["index"]] = cur_test["body"]
        else:
            filled_map[leaf["index"]] = val

    if cur_func:
        funcs.append(cur_func)
    if cur_test:
        tests.append(cur_test)

    code = assemble(intent, mod_doc, imports, funcs, tests)

    # cocycle: every referenced name in every function body must be
    # a parameter, a builtin, or a function defined earlier.
    import ast as _ast, builtins as _b
    violations: List[str] = []
    try:
        tree = _ast.parse(code)
        defined = set(dir(_b)) | {
            "__name__", "__file__", "__doc__", "__builtins__",
            "__package__", "annotations",
        }
        for n in _ast.walk(tree):
            if isinstance(n, (_ast.FunctionDef, _ast.AsyncFunctionDef)):
                defined.add(n.name)
            elif isinstance(n, _ast.Import):
                for a in n.names:
                    defined.add((a.asname or a.name).split(".")[0])
            elif isinstance(n, _ast.ImportFrom):
                for a in n.names:
                    defined.add(a.asname or a.name)
            elif isinstance(n, _ast.arg):
                defined.add(n.arg)
            elif isinstance(n, _ast.Assign):
                for t in n.targets:
                    if isinstance(t, _ast.Name):
                        defined.add(t.id)
            elif isinstance(n, _ast.AnnAssign) and isinstance(n.target, _ast.Name):
                defined.add(n.target.id)
            elif isinstance(n, _ast.For) and isinstance(n.target, _ast.Name):
                defined.add(n.target.id)
            elif isinstance(n, _ast.withitem) and isinstance(n.optional_vars, _ast.Name):
                defined.add(n.optional_vars.id)
            elif isinstance(n, _ast.comprehension) and isinstance(n.target, _ast.Name):
                defined.add(n.target.id)
        used = {n.id for n in _ast.walk(tree)
                if isinstance(n, _ast.Name) and isinstance(n.ctx, _ast.Load)}
        unknown = sorted(used - defined)
        if unknown:
            violations.append(f"undefined: {unknown}")
    except SyntaxError as e:
        violations.append(f"syntax: line {e.lineno}: {e.msg}")

    cocycle_ok = not violations

    new_terminals = [filled_map.get(l["index"], l["leaf"]) for l in leaves]
    text = "\n".join(f"[{l['nt']}] {new_terminals[i]}"
                     for i, l in enumerate(leaves))

    return DispatchResult(
        grammar_name=grammar.name, seed=seed, intent=intent,
        leaves=len(leaves), filled=len(filled_map),
        terminals=new_terminals, text=text, tree=d["tree"],
        code=code, cocycle_ok=cocycle_ok, violations=violations,
        sections={"mod_doc": mod_doc, "imports": imports,
                  "functions": funcs, "tests": tests},
        swarm={"n_workers": swarm.n,
               "filled": [w.to_dict() for w in worker_log]},
    )


def _strip_fences(s: str) -> str:
    s = s.strip()
    m = _FENCE_RE.search(s)
    if m:
        s = m.group(1)
    return s.strip()


def refine(source: str, swarm: Swarm, intent: str = "",
           max_tokens: int = 512) -> str:
    if not source.strip():
        return source
    head = "You are a Python fixer."
    if intent:
        head += " Intent: " + intent + "."
    prompt = (head + " Return only the corrected source. No fences.\n\n"
              + source)
    r = swarm.run_one(0, prompt, max_tokens=max_tokens)
    return _strip_fences(r.text)
