class Symbol:
    def __init__(self, name: str, **kwargs):
        self.name = name
        for k, v in kwargs.items():
            setattr(self, k, v)
    def __repr__(self):
        return f"Symbol({self.name})"

class OrigamiGrammar:
    def __init__(self, rules: list = None, **kwargs):
        self.rules = rules or []
        for k, v in kwargs.items():
            setattr(self, k, v)

    def fold(self, structure: str) -> str:
        return f"folded:{structure}"
