"""Backtracking solver with MRV and forward checking."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from app.puzzles.grid import Grid, VarId


@dataclass
class Solution:
    assignment: Dict[VarId, Any]
    nodes: int
    complete: bool
    trace: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {"assignment": dict(self.assignment),
                "nodes": self.nodes, "complete": self.complete}


def _mrv(grid, assignment):
    best_id = None
    best = None
    for vid, v in grid.vars.items():
        if vid in assignment:
            continue
        n = len(v.domain)
        if best is None or n < best:
            best = n
            best_id = vid
    return best_id


def _consistent(grid, assignment):
    for c in grid.constraints:
        if not c.satisfied(assignment):
            return False
    return True


def solve(grid: Grid, max_nodes: int = 1_000_000) -> Solution:
    assignment = {}
    nodes = [0]

    def bt():
        if len(assignment) == len(grid.vars):
            return True
        vid = _mrv(grid, assignment)
        if vid is None:
            return True
        var = grid.vars[vid]
        for value in var.domain:
            assignment[vid] = value
            nodes[0] += 1
            if nodes[0] > max_nodes:
                del assignment[vid]
                return False
            if _consistent(grid, assignment):
                if bt():
                    return True
            del assignment[vid]
        return False

    ok = bt()
    return Solution(assignment=dict(assignment), nodes=nodes[0], complete=ok)
