from app.seed.manifest import CPVORates, Manifest

class CPVORecord:
    def __init__(self, id: str = "", value: float = 0.0, **kwargs):
        self.id = id
        self.value = value
        for k, v in kwargs.items():
            setattr(self, k, v)

class CPVOMeter:
    def __init__(self, rates: CPVORates = None, **kwargs):
        self.rates = rates or CPVORates()
        for k, v in kwargs.items():
            setattr(self, k, v)

    def measure(self, record: CPVORecord) -> float:
        return record.value * self.rates.rate
