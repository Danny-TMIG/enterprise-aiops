class CPVORates:
    def __init__(self, rate: float = 1.0, **kwargs):
        self.rate = rate
        for k, v in kwargs.items():
            setattr(self, k, v)

class Manifest:
    def __init__(self, version: str = "1.0", components: list = None, **kwargs):
        self.version = version
        self.components = components or []
        for k, v in kwargs.items():
            setattr(self, k, v)

def load_manifest(path: str = "manifest.json") -> Manifest:
    return Manifest()
