from __future__ import annotations
from pathlib import Path
from typing import Any, Dict, List, Optional

from app.seed.manifest import Manifest, load_manifest
from app.seed.intent import Intent, from_cli, from_api
from app.seed.workflow import Workflow


class SeedRuntime:
    def __init__(self, manifest: Optional[Manifest] = None,
                 root: Optional[str] = None) -> None:
        self.root = str(Path(root or ".").resolve())
        self.manifest = manifest or load_manifest(
            str(Path(self.root) / "mesh-seed.yaml"))
        self.runs: Dict[str, Workflow] = {}

    def start(self, intent: Intent) -> Workflow:
        wf = Workflow(intent=intent, manifest=self.manifest)
        self.runs[intent.id] = wf
        return wf

    def start_cli(self, text: str, target: str = "",
                  author: str = "user") -> Workflow:
        return self.start(from_cli(text, target=target, author=author))

    def start_api(self, payload: Dict[str, Any]) -> Workflow:
        return self.start(from_api(payload))

    def get(self, intent_id: str) -> Optional[Workflow]:
        return self.runs.get(intent_id)

    def all(self) -> List[Dict[str, Any]]:
        return [w.to_dict() for w in self.runs.values()]

    def status(self) -> Dict[str, Any]:
        counts: Dict[str, int] = {}
        for w in self.runs.values():
            counts[w.state.value] = counts.get(w.state.value, 0) + 1
        return {
            "root": self.root,
            "manifest": self.manifest.to_dict(),
            "runs": len(self.runs),
            "by_state": counts,
        }


_RT: Optional[SeedRuntime] = None


def get_seed() -> SeedRuntime:
    global _RT
    if _RT is None:
        _RT = SeedRuntime()
    return _RT
