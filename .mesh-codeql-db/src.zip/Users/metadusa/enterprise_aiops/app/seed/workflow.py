from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional

from app.seed.artifact import generate as _gen_artifact
from app.seed.counter import record_emit
from app.seed.cpvo import CPVOMeter, CPVORecord
from app.seed.gates import Gate, GateError
from app.seed.intent import Intent
from app.seed.manifest import Manifest
from app.seed.proof_object import ProofObject
from app.seed.seal import seal
from app.seed.spec import Spec, draft as _draft_spec


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


class WorkflowState(str, Enum):
    RECEIVED = "RECEIVED"
    SPEC_DRAFTED = "SPEC_DRAFTED"
    SPEC_APPROVED = "SPEC_APPROVED"
    ARTIFACT_GENERATED = "ARTIFACT_GENERATED"
    SCANNED = "SCANNED"
    PROVED = "PROVED"
    KERNEL_CHECKED = "KERNEL_CHECKED"
    PROOF_EMITTED = "PROOF_EMITTED"
    DELIVERED = "DELIVERED"
    MERGED = "MERGED"
    REJECTED = "REJECTED"
    FAILED = "FAILED"


@dataclass
class Workflow:
    intent: Intent
    manifest: Manifest
    state: WorkflowState = WorkflowState.RECEIVED
    spec: Optional[Spec] = None
    artifact: Any = None
    scan_results: List[Dict[str, Any]] = field(default_factory=list)
    proof_results: List[Dict[str, Any]] = field(default_factory=list)
    kernel_result: Dict[str, Any] = field(default_factory=dict)
    proof_object: Optional[ProofObject] = None
    cpvo: CPVOMeter = field(init=False)
    gates: Dict[str, Gate] = field(init=False)
    events: List[Dict[str, Any]] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.cpvo = CPVOMeter(self.manifest.cpvo)
        self.gates = {"spec": Gate("spec"), "delivery": Gate("delivery")}
        self._log("RECEIVED", {"intent_id": self.intent.id})

    def _log(self, event: str, data: Dict[str, Any]) -> None:
        self.events.append({"event": event, "ts": _now(), "data": data})

    def _advance(self, to: WorkflowState) -> None:
        self.state = to
        self._log(to.value, {})

    def draft_spec(self) -> Spec:
        if self.state != WorkflowState.RECEIVED:
            raise GateError(f"cannot draft spec from {self.state}")
        self.spec = _draft_spec(self.intent).freeze()
        self._advance(WorkflowState.SPEC_DRAFTED)
        return self.spec

    def approve_spec(self, by: str, note: str = "") -> None:
        if self.state != WorkflowState.SPEC_DRAFTED:
            raise GateError(f"spec gate requires SPEC_DRAFTED, got {self.state}")
        d = self.gates["spec"].approve(by, note)
        self._log("gate_spec_approved", d.to_dict())
        self._advance(WorkflowState.SPEC_APPROVED)

    def reject_spec(self, by: str, note: str = "") -> None:
        if self.state != WorkflowState.SPEC_DRAFTED:
            raise GateError(f"spec gate requires SPEC_DRAFTED, got {self.state}")
        d = self.gates["spec"].reject(by, note)
        self._log("gate_spec_rejected", d.to_dict())
        self._advance(WorkflowState.REJECTED)

    def generate_artifact(self) -> Any:
        if self.state != WorkflowState.SPEC_APPROVED:
            raise GateError(f"artifact requires SPEC_APPROVED, got {self.state}")
        self.artifact = _gen_artifact(self.spec)
        self._advance(WorkflowState.ARTIFACT_GENERATED)
        return self.artifact

    def scan(self, root: str = ".") -> List[Dict[str, Any]]:
        if self.state != WorkflowState.ARTIFACT_GENERATED:
            raise GateError(f"scan requires ARTIFACT_GENERATED, got {self.state}")
        from app.dis.scan.registry import ScanRegistry
        reg = ScanRegistry()
        for name in self.manifest.verification.scan:
            res = reg.scan(name, root)
            self.scan_results.append(res.to_dict())
        self._advance(WorkflowState.SCANNED)
        return self.scan_results

    def prove(self) -> List[Dict[str, Any]]:
        if self.state != WorkflowState.SCANNED:
            raise GateError(f"prove requires SCANNED, got {self.state}")
        from app.dis.verification.registry import VerificationRegistry
        reg = VerificationRegistry()
        stmt = (self.spec.what if self.spec else "") or self.intent.raw
        for name in self.manifest.verification.prove:
            res = reg.prove(name, stmt,
                            {"lean": self.artifact.proof_target if self.artifact else ""})
            self.proof_results.append(res.to_dict())
        self._advance(WorkflowState.PROVED)
        return self.proof_results

    def kernel_check(self) -> Dict[str, Any]:
        if self.state != WorkflowState.PROVED:
            raise GateError(f"kernel requires PROVED, got {self.state}")
        from app.dis.verification.registry import VerificationRegistry
        reg = VerificationRegistry()
        res = reg.prove(
            self.manifest.verification.kernel,
            self.spec.what if self.spec else self.intent.raw,
            {"lean": self.artifact.proof_target if self.artifact else ""},
        )
        self.kernel_result = res.to_dict()
        self._advance(WorkflowState.KERNEL_CHECKED)
        return self.kernel_result

    def emit_proof_object(self) -> ProofObject:
        if self.state != WorkflowState.KERNEL_CHECKED:
            raise GateError(f"proof object requires KERNEL_CHECKED, got {self.state}")

        try:
            from app.mesh.runtime import get_mesh
            m = get_mesh()
            dg = {"stats": m.graph.stats(),
                  "edges": [e.to_dict() for e in m.graph.edges][:200]}
        except Exception:
            dg = {"stats": {}, "edges": []}

        input_tokens = sum(r.get("usage", {}).get("input_tokens", 0)
                           for r in self.proof_results)
        output_tokens = sum(r.get("usage", {}).get("output_tokens", 0)
                            for r in self.proof_results)
        verify_ms = sum(int(r.get("elapsed_ms", 0)) for r in self.proof_results)
        kernel_pass = self.kernel_result.get("status") == "PASS"
        rec = CPVORecord(run_id=self.intent.id,
                         input_tokens=input_tokens,
                         output_tokens=output_tokens,
                         compute_ms=verify_ms // 2,
                         verify_ms=verify_ms,
                         verified=kernel_pass)
        self.cpvo.record(rec)

        po = ProofObject(
            intent=self.intent.to_dict(),
            spec=self.spec.to_dict() if self.spec else {},
            artifact=self.artifact.to_dict() if self.artifact else {},
            scan=self.scan_results,
            proof=self.proof_results,
            kernel=self.kernel_result,
            dependency_graph=dg,
            cpvo=self.cpvo.totals(),
            gates=[self.gates["spec"].to_dict(),
                   self.gates["delivery"].to_dict()],
        ).finalize()
        po.seal = seal(po.without_seal(), keyid="mesh-seed")
        self.proof_object = po
        try:
            record_emit(po.to_dict())
        except Exception:
            pass

        # record into the moat's persistent history so every layer
        # that reads history (P_g, X_h) sees this run
        try:
            from app.moat.moat import record_run
            record_run(po.to_dict(), merged=False)
        except Exception:
            pass

        self._advance(WorkflowState.PROOF_EMITTED)
        return po

    def approve_delivery(self, by: str, note: str = "") -> None:
        if self.state != WorkflowState.PROOF_EMITTED:
            raise GateError(f"delivery gate requires PROOF_EMITTED, got {self.state}")
        d = self.gates["delivery"].approve(by, note)
        self._log("gate_delivery_approved", d.to_dict())
        if self.proof_object is not None:
            self.proof_object.gates = [
                self.gates["spec"].to_dict(),
                self.gates["delivery"].to_dict(),
            ]
            self.proof_object.seal = seal(self.proof_object.without_seal(),
                                          keyid="mesh-seed")
        try:
            from app.moat.moat import record_run
            if self.proof_object is not None:
                record_run(self.proof_object.to_dict(), merged=True)
        except Exception:
            pass
        self._advance(WorkflowState.DELIVERED)

    def reject_delivery(self, by: str, note: str = "") -> None:
        if self.state != WorkflowState.PROOF_EMITTED:
            raise GateError(f"delivery gate requires PROOF_EMITTED, got {self.state}")
        d = self.gates["delivery"].reject(by, note)
        self._log("gate_delivery_rejected", d.to_dict())
        self._advance(WorkflowState.REJECTED)

    def merge(self) -> None:
        if self.state != WorkflowState.DELIVERED:
            raise GateError(f"merge requires DELIVERED, got {self.state}")
        self._advance(WorkflowState.MERGED)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "state": self.state.value,
            "intent": self.intent.to_dict(),
            "spec": self.spec.to_dict() if self.spec else None,
            "artifact": self.artifact.to_dict() if self.artifact else None,
            "scan": self.scan_results,
            "proof": self.proof_results,
            "kernel": self.kernel_result,
            "proof_object": self.proof_object.to_dict() if self.proof_object else None,
            "cpvo": self.cpvo.to_dict(),
            "gates": {k: v.to_dict() for k, v in self.gates.items()},
            "events": self.events,
        }
