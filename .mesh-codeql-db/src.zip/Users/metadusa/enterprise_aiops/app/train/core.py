"""Parallel training core.

A Trainer runs one (kind, solver, difficulty) cell and records
the outcome as evidence. Outcomes flow into three sinks in
parallel:

    1. delta       - SFT/DPO pairs for downstream fine-tuning
    2. tower       - CD level tracker per solver
    3. publish     - hopping schedule + DD reference for the mesh

Every tile runs in a thread; the trainer is agnostic to whether
solver work is I/O or CPU bound.
"""
from __future__ import annotations
import concurrent.futures as cf
import hashlib, time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

from app.engines.kinds import KINDS, SOLVERS
from app.engines.parallel import run_grid, Outcome, Tile


def _h(*p: str) -> str:
    m = hashlib.sha256()
    for s in p:
        m.update(s.encode("utf-8")); m.update(b"\x1f")
    return "sha256:" + m.hexdigest()[:16]


@dataclass
class TrainConfig:
    kinds: List[str] = field(default_factory=lambda: sorted(KINDS.keys()))
    difficulties: List[str] = field(default_factory=lambda: ["easy", "medium", "hard"])
    puzzles_per_tile: int = 4
    seed: int = 0
    max_workers: Optional[int] = None


@dataclass
class TrainOutcome:
    kind: str
    solver: str
    difficulty: str
    puzzle_id: int
    passed: bool
    duration_ms: float
    digest: str

    def to_dict(self):
        return {"kind": self.kind, "solver": self.solver,
                "difficulty": self.difficulty, "puzzle_id": self.puzzle_id,
                "passed": self.passed,
                "duration_ms": round(self.duration_ms, 2),
                "digest": self.digest}


@dataclass
class TrainTile:
    kind: str
    solver: str
    difficulty: str
    trials: int
    passes: int
    duration_ms: float

    @property
    def rate(self) -> float:
        return self.passes / self.trials if self.trials else 0.0

    def to_dict(self):
        return {"kind": self.kind, "solver": self.solver,
                "difficulty": self.difficulty, "trials": self.trials,
                "passes": self.passes, "rate": round(self.rate, 4),
                "duration_ms": round(self.duration_ms, 2)}


@dataclass
class Run:
    index: int
    tiles: List[TrainTile]
    outcomes: List[TrainOutcome]
    duration_ms: float
    digest: str

    def to_dict(self):
        return {"index": self.index,
                "digest": self.digest,
                "duration_ms": round(self.duration_ms, 2),
                "tiles": [t.to_dict() for t in self.tiles]}


class Trainer:
    def __init__(self, cfg: TrainConfig):
        self.cfg = cfg
        self.runs: List[Run] = []

    def _one(self, kind: str, solver: str, difficulty: str,
             seed: int, puzzle_id: int) -> TrainOutcome:
        t0 = time.time()
        try:
            k = KINDS[kind]
            s = SOLVERS[kind][solver]
            puzzle = k.sample(difficulty, seed)
            attempt = s(puzzle, seed)
            ok = bool(k.verify(puzzle, attempt))
            d = _h(kind, solver, difficulty, str(seed), str(puzzle_id),
                   "pass" if ok else "fail")
            return TrainOutcome(kind, solver, difficulty, puzzle_id,
                                ok, (time.time() - t0) * 1000.0, d)
        except Exception as e:
            d = _h(kind, solver, difficulty, str(seed), type(e).__name__)
            return TrainOutcome(kind, solver, difficulty, puzzle_id,
                                False, (time.time() - t0) * 1000.0,
                                d)

    def run_once(self, index: int) -> Run:
        t0 = time.time()
        jobs: List[Tuple[str, str, str, int, int]] = []
        for kind in self.cfg.kinds:
            for diff in self.cfg.difficulties:
                for solver in SOLVERS.get(kind, {}):
                    for j in range(self.cfg.puzzles_per_tile):
                        jobs.append((kind, solver, diff,
                                     self.cfg.seed + j, j))

        outcomes: List[TrainOutcome] = []
        with cf.ThreadPoolExecutor(max_workers=self.cfg.max_workers) as pool:
            futs = [pool.submit(self._one, *j) for j in jobs]
            for f in futs:
                try:
                    outcomes.append(f.result())
                except Exception:
                    pass

        by: Dict[Tuple[str, str, str], TrainTile] = {}
        for o in outcomes:
            key = (o.kind, o.solver, o.difficulty)
            t = by.get(key)
            if t is None:
                t = TrainTile(o.kind, o.solver, o.difficulty,
                              trials=0, passes=0, duration_ms=0.0)
                by[key] = t
            t.trials += 1
            t.passes += int(o.passed)
            t.duration_ms += o.duration_ms

        r = Run(index=index, tiles=list(by.values()), outcomes=outcomes,
                duration_ms=(time.time() - t0) * 1000.0,
                digest=_h("run", str(index), str(len(outcomes)),
                          str(sum(o.passed for o in outcomes))))
        self.runs.append(r)
        return r
