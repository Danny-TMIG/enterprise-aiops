"""Weave every mesh into one.

Sources:
    app.engines.parallel       - grid runner
    app.delta.delta            - quadrants
    app.murmur.flock           - agents
    app.ddlong.chain           - hopping
    app.combinator.reduce      - IC reduction
    app.cd_nand.cayley         - CD levels
    app.transchain.gen         - A..Z chains

Outputs:
    weave         - every (kind x solver x difficulty) → one stream
    criss_cross   - zigzag interleave of two run digests
    trans         - prefix closure over digests
    pollinate     - cross product of two meshes; emits pair records
"""
from __future__ import annotations
import hashlib
from dataclasses import dataclass, field
from itertools import product
from typing import Any, Dict, Iterable, List, Tuple

from app.train.core import Run, TrainTile, TrainOutcome


def _h(*p: str) -> str:
    m = hashlib.sha256()
    for s in p:
        m.update(s.encode("utf-8")); m.update(b"\x1f")
    return "sha256:" + m.hexdigest()[:16]


@dataclass
class MeshOfMeshes:
    """All source meshes held in one container."""
    runs: List[Run] = field(default_factory=list)
    tiles_by_kind: Dict[str, List[TrainTile]] = field(default_factory=dict)
    digests: List[str] = field(default_factory=list)
    size: int = 0

    def add_run(self, run: Run) -> None:
        self.runs.append(run)
        for t in run.tiles:
            self.tiles_by_kind.setdefault(t.kind, []).append(t)
        self.digests.append(run.digest)
        self.size += len(run.outcomes)

    def to_dict(self):
        return {"runs": len(self.runs), "size": self.size,
                "digests": list(self.digests)}


def weave(*runs: Run) -> MeshOfMeshes:
    m = MeshOfMeshes()
    for r in runs:
        m.add_run(r)
    return m


def criss_cross(a: Run, b: Run) -> Dict[str, Any]:
    """Zigzag the two run digests into a combined digest.
    The pattern is a[0], b[0], a[1], b[1], ... """
    ha = list(a.digest)
    hb = list(b.digest)
    out = []
    i = j = 0
    while i < len(ha) or j < len(hb):
        if i < len(ha):
            out.append(ha[i]); i += 1
        if j < len(hb):
            out.append(hb[j]); j += 1
    zig = "".join(out)
    return {
        "zigzag": zig,
        "combined": _h("zig", a.digest, b.digest),
        "a_index": a.index, "b_index": b.index,
        "length": len(zig),
    }


def trans(runs: List[Run]) -> Dict[str, Any]:
    """Prefix closure over the run digests. Two digests are
    adjacent iff one is a prefix of the other, or they share the
    first 8 hex chars."""
    edges: List[Tuple[str, str]] = []
    digests = [r.digest for r in runs]
    for d1 in digests:
        for d2 in digests:
            if d1 == d2:
                continue
            if d1.startswith(d2[:8]) or d2.startswith(d1[:8]):
                edges.append((d1, d2))
    reach: Dict[str, set] = {d: set() for d in digests}
    adj: Dict[str, List[str]] = {d: [] for d in digests}
    for u, v in edges:
        adj[u].append(v)
    for start in digests:
        stack = [start]
        while stack:
            u = stack.pop()
            for v in adj.get(u, []):
                if v not in reach[start]:
                    reach[start].add(v)
                    stack.append(v)
    return {
        "digests": digests,
        "edges": len(edges),
        "transitive_pairs": sum(len(v) for v in reach.values()),
        "reach": {k: sorted(v) for k, v in reach.items()},
    }


def pollinate(a: Run, b: Run) -> List[Dict[str, Any]]:
    """Cross product of two runs. For every (ta, tb) with ta.kind ==
    tb.kind, emit a pollinate record naming both solvers and their
    rates."""
    out: List[Dict[str, Any]] = []
    by_a = {(t.kind, t.difficulty): t for t in a.tiles}
    by_b = {(t.kind, t.difficulty): t for t in b.tiles}
    for k in sorted(set(x[0] for x in by_a) | set(x[0] for x in by_b)):
        for d in sorted(set(x[1] for x in by_a if x[0] == k)
                        | set(x[1] for x in by_b if x[0] == k)):
            ta = by_a.get((k, d))
            tb = by_b.get((k, d))
            if ta is None or tb is None:
                continue
            out.append({
                "kind": k, "difficulty": d,
                "a_solver": ta.solver, "a_rate": round(ta.rate, 4),
                "b_solver": tb.solver, "b_rate": round(tb.rate, 4),
                "delta": round(ta.rate - tb.rate, 4),
                "id": _h("poll", k, d, ta.solver, tb.solver),
            })
    return out
