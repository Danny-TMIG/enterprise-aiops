import sqlite3
import pytest
from pathlib import Path

@pytest.fixture
def strata_db(tmp_path):
    """Fresh sqlite database with the schema the strata tests need."""
    db_path = tmp_path / "strata.db"
    con = sqlite3.connect(db_path)
    con.executescript("""
        CREATE TABLE IF NOT EXISTS strata (
            id INTEGER PRIMARY KEY,
            name TEXT UNIQUE,
            size_bytes INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS retention (
            id INTEGER PRIMARY KEY,
            stratum_id INTEGER NOT NULL,
            pruned_at TEXT NOT NULL DEFAULT (datetime('now')),
            bytes_freed INTEGER NOT NULL DEFAULT 0,
            reason TEXT,
            FOREIGN KEY(stratum_id) REFERENCES strata(id) ON DELETE CASCADE
        );
    """)
    con.commit()
    yield con
    con.close()
