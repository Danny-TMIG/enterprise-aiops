from app.dis import get_registry, ModelRequest

def test_registry():
    reg = get_registry()
    model_info = reg.get("default")
    assert model_info["provider"] == "local"
