"""Cross-layer integration tests.

Every layer is present, imports cleanly, and the unified /status
endpoint reports no errors. This is the canary that catches
"the last build broke everything".
"""
import json
from pathlib import Path

import pytest


def test_all_layers_import():
    from app.mesh.runtime import get_mesh
    from app.dis.runtime import get_dis
    from app.autonomy.runtime import get_runtime
    from app.seed.runtime import get_seed
    from app.topos.runtime import get_topos
    assert callable(get_mesh)
    assert callable(get_dis)
    assert callable(get_runtime)
    assert callable(get_seed)
    assert callable(get_topos)


def test_unified_status_ok():
    from app.status import unified_status
    st = unified_status()
    assert "layers" in st
    assert "ok" in st
    json.dumps(st, default=str)  # must be serializable


def test_mesh_has_graph():
    from app.mesh.runtime import get_mesh
    m = get_mesh()
    assert m.graph.stats()["nodes"] > 0


def test_dis_has_all_providers():
    from app.dis.runtime import get_dis
    d = get_dis()
    st = d.status()
    assert set(st["models"]["providers"]) == {
        "anthropic", "openai", "deepseek", "mistral",
    }
    assert set(st["orchestration"]) == {
        "microsoft", "salesforce", "servicenow", "google",
    }
    assert set(st["verification"]) == {
        "leandojo", "prove2me", "lean4agent", "lean4-kernel",
    }


def test_seed_pipeline_and_topos_record():
    from app.seed.runtime import SeedRuntime
    from app.topos.runtime import ToposRuntime
    ROOT = str(Path(__file__).resolve().parent.parent)

    seed = SeedRuntime(root=ROOT)
    wf = seed.start_cli("add a health check to /status")
    wf.draft_spec()
    wf.approve_spec(by="alice")
    wf.generate_artifact()
    wf.scan(root=ROOT)
    wf.prove()
    wf.kernel_check()
    po = wf.emit_proof_object()
    d = po.to_dict()
    assert d["kernel"]["prover"] == "lean4-kernel"
    assert [g["name"] for g in d["gates"]] == ["spec", "delivery"]

    top = ToposRuntime()
    top.record_seed_run({
        "intent": d["intent"], "spec": d["spec"],
        "artifact": d["artifact"], "kernel": d["kernel"],
    })
    assert top.status()["runs_recorded"] == 1
    assert top.T.is_topos()
