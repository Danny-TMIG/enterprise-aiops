from app.origami.grammar import Symbol, OrigamiGrammar

def test_symbol():
    sym = Symbol(name="alpha")
    assert sym.name == "alpha"
    assert "alpha" in repr(sym)

def test_origami_grammar():
    og = OrigamiGrammar()
    assert og.fold("cube") == "folded:cube"
