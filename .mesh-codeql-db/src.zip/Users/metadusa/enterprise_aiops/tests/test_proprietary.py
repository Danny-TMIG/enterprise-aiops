import json
from app.proprietary.registry import ProprietaryRegistry
from app.proprietary.microsoft import MicrosoftObject
from app.proprietary.salesforce import SalesforceObject
from app.proprietary.servicenow import ServiceNowObject
from app.proprietary.google import GoogleObject
from app.proprietary.codacy import CodacyObject
from app.proprietary.leandojo import LeanDojoObject


def test_registry_has_six_vendors():
    reg = ProprietaryRegistry()
    assert set(reg.objects) == {
        "microsoft", "salesforce", "servicenow",
        "google", "codacy", "leandojo",
    }


def test_all_objects_are_real_via_local():
    reg = ProprietaryRegistry()
    for name, o in reg.objects.items():
        assert o.is_real(), f"{name} is not real"
        assert o.has_local(), f"{name} has no local impl"


def test_reality_score_is_one():
    s = ProprietaryRegistry().reality_score()
    assert s["reality_fraction"] == 1.0
    assert s["real"] == s["vendors"] == 6
    assert len(s["local_only"]) == 6


# ── wire formats ───────────────────────────────────────────────
def test_microsoft_wire_format():
    r = MicrosoftObject().invoke({"claim": "x", "evidence": []})
    assert r["ok"] is True
    assert r["body"]["status"] == "succeeded"
    assert r["body"]["outputs"]["verdict"] == "PASS"


def test_salesforce_wire_format():
    r = SalesforceObject().invoke({"claim": "x", "context": {"a": 1}})
    assert r["ok"] is True
    assert r["body"]["success"] is True
    assert r["body"]["data"]["verdict"] == "PASS"


def test_servicenow_wire_format():
    r = ServiceNowObject().invoke({"inputs": {"claim": "x"}})
    assert r["ok"] is True
    assert r["body"]["result"]["state"] == "success"
    assert r["body"]["result"]["output"]["verdict"] == "PASS"


def test_google_wire_format():
    r = GoogleObject().invoke({"parameters": {"claim": "x"}})
    assert r["ok"] is True
    assert "fulfillmentResponse" in r["body"]
    assert r["body"]["fulfillmentResponse"]["verdict"] == "PASS"


def test_empty_claim_fails_on_all_orchestrators():
    for obj in (MicrosoftObject(), SalesforceObject(),
                ServiceNowObject(), GoogleObject()):
        r = obj.invoke({"claim": ""})
        # some vendors signal failure in body, some in status
        body = r.get("body") or {}
        text = json.dumps(body)
        assert "FAIL" in text or '"failed"' in text or '"error"' in text, \
            f"{obj.vendor} did not reject empty claim"


# ── codacy local scanner ───────────────────────────────────────
def test_codacy_detects_unused_import():
    src = "import os\nimport sys\nprint(sys.argv)\n"
    r = CodacyObject().invoke({"files": {"x.py": src}})
    assert r["ok"] is True
    issues = r["body"]["issues"]
    assert any(i["patternId"] == "unused_import" for i in issues)


def test_codacy_detects_bare_except():
    src = "try:\n    pass\nexcept:\n    pass\n"
    r = CodacyObject().invoke({"files": {"x.py": src}})
    issues = r["body"]["issues"]
    assert any(i["patternId"] == "bare_except" for i in issues)


def test_codacy_detects_todo():
    src = "# TODO: fix\nx = 1\n"
    r = CodacyObject().invoke({"files": {"x.py": src}})
    issues = r["body"]["issues"]
    assert any(i["patternId"] == "todo_comment" for i in issues)


def test_codacy_clean_file_has_no_issues():
    src = "def f(x: int) -> int:\n    return x + 1\n"
    r = CodacyObject().invoke({"files": {"x.py": src}})
    assert r["body"]["total"] == 0


def test_codacy_syntax_error():
    src = "def f(:\n"
    r = CodacyObject().invoke({"files": {"x.py": src}})
    assert any(i["patternId"] == "syntax_error" for i in r["body"]["issues"])


# ── leandojo local tracer ──────────────────────────────────────
def test_leandojo_accepts_trivial_theorem():
    r = LeanDojoObject().invoke({
        "theorem": "theorem t : True := by trivial",
    })
    assert r["ok"] is True
    assert r["body"]["status"] == "passed"
    assert r["body"]["statement"] == "True"
    assert r["body"]["steps"] == [{"tactic": "trivial"}]


def test_leandojo_multi_line_tactic():
    thm = "theorem t : 1 + 1 = 2 := by\n  simp\n  rfl"
    r = LeanDojoObject().invoke({"theorem": thm})
    assert r["body"]["status"] == "passed"
    assert r["body"]["tactic_lines"] == 2


def test_leandojo_rejects_non_theorem():
    r = LeanDojoObject().invoke({"theorem": "just a string"})
    assert r["body"]["status"] == "failed"


def test_leandojo_rejects_empty():
    r = LeanDojoObject().invoke({"theorem": ""})
    assert r["body"]["status"] == "failed"


# ── serialization ──────────────────────────────────────────────
def test_registry_status_serializable():
    json.dumps(ProprietaryRegistry().status(), default=str)


def test_registry_invoke_unknown():
    r = ProprietaryRegistry().invoke("nope", {})
    assert r["ok"] is False
    assert r["reason"] == "unknown"
